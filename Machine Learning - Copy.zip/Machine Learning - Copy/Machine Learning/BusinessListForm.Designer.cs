﻿namespace Machine_Learning
{
    partial class BusinessListForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            createIdeaButton = new Button();
            createIdeaText = new TextBox();
            ideaEntryLabel = new Label();
            addBusinessButton = new Button();
            label1 = new Label();
            addBusinessText = new TextBox();
            businessDGV = new DataGridView();
            modelInfoLabel = new Label();
            businessPageButton = new Button();
            mergerPageButton = new Button();
            ((System.ComponentModel.ISupportInitialize)businessDGV).BeginInit();
            SuspendLayout();
            // 
            // createIdeaButton
            // 
            createIdeaButton.Location = new Point(478, 85);
            createIdeaButton.Name = "createIdeaButton";
            createIdeaButton.Size = new Size(94, 29);
            createIdeaButton.TabIndex = 0;
            createIdeaButton.Text = "Create Idea";
            createIdeaButton.UseVisualStyleBackColor = true;
            createIdeaButton.Click += createIdeaButton_Click;
            // 
            // createIdeaText
            // 
            createIdeaText.Location = new Point(461, 52);
            createIdeaText.Name = "createIdeaText";
            createIdeaText.Size = new Size(125, 27);
            createIdeaText.TabIndex = 2;
            // 
            // ideaEntryLabel
            // 
            ideaEntryLabel.AutoSize = true;
            ideaEntryLabel.Location = new Point(379, 9);
            ideaEntryLabel.Name = "ideaEntryLabel";
            ideaEntryLabel.Size = new Size(295, 40);
            ideaEntryLabel.TabIndex = 3;
            ideaEntryLabel.Text = "Enter the first two words of a business idea,\r\nand AI will finish it for you!\r\n";
            ideaEntryLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // addBusinessButton
            // 
            addBusinessButton.Location = new Point(190, 85);
            addBusinessButton.Name = "addBusinessButton";
            addBusinessButton.Size = new Size(108, 29);
            addBusinessButton.TabIndex = 4;
            addBusinessButton.Text = "Add Business";
            addBusinessButton.UseVisualStyleBackColor = true;
            addBusinessButton.Click += addBusinessButton_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(141, 9);
            label1.Name = "label1";
            label1.Size = new Size(205, 40);
            label1.TabIndex = 5;
            label1.Text = "Enter 3 words that summarize\r\na successful business\r\n";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // addBusinessText
            // 
            addBusinessText.Location = new Point(183, 52);
            addBusinessText.Name = "addBusinessText";
            addBusinessText.Size = new Size(125, 27);
            addBusinessText.TabIndex = 6;
            // 
            // businessDGV
            // 
            businessDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            businessDGV.Location = new Point(12, 198);
            businessDGV.Name = "businessDGV";
            businessDGV.RowHeadersWidth = 51;
            businessDGV.Size = new Size(776, 240);
            businessDGV.TabIndex = 7;
            // 
            // modelInfoLabel
            // 
            modelInfoLabel.AutoSize = true;
            modelInfoLabel.Location = new Point(319, 147);
            modelInfoLabel.Name = "modelInfoLabel";
            modelInfoLabel.Size = new Size(0, 20);
            modelInfoLabel.TabIndex = 8;
            // 
            // businessPageButton
            // 
            businessPageButton.Location = new Point(12, 163);
            businessPageButton.Name = "businessPageButton";
            businessPageButton.Size = new Size(94, 29);
            businessPageButton.TabIndex = 11;
            businessPageButton.Text = "button2";
            businessPageButton.UseVisualStyleBackColor = true;
            // 
            // mergerPageButton
            // 
            mergerPageButton.Location = new Point(553, 163);
            mergerPageButton.Name = "mergerPageButton";
            mergerPageButton.Size = new Size(94, 29);
            mergerPageButton.TabIndex = 12;
            mergerPageButton.Text = "button2";
            mergerPageButton.UseVisualStyleBackColor = true;
            // 
            // BusinessListForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(mergerPageButton);
            Controls.Add(businessPageButton);
            Controls.Add(modelInfoLabel);
            Controls.Add(businessDGV);
            Controls.Add(addBusinessText);
            Controls.Add(label1);
            Controls.Add(addBusinessButton);
            Controls.Add(ideaEntryLabel);
            Controls.Add(createIdeaText);
            Controls.Add(createIdeaButton);
            Name = "BusinessListForm";
            Text = "Successful business";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)businessDGV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button createIdeaButton;
        private TextBox createIdeaText;
        private Label ideaEntryLabel;
        private Button addBusinessButton;
        private Label label1;
        private TextBox addBusinessText;
        private DataGridView businessDGV;
        private Label modelInfoLabel;
        private Button businessPageButton;
        private Button mergerPageButton;
    }
}
