using System.Data;
using System.Data.SQLite;
using System.Xml.Linq;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace Machine_Learning
{
    
    
    
    public partial class BusinessListForm : Form
    {
        private RegressionMLService _service = new RegressionMLService();
        //get path
        private string strDBPath = "business.db";

        
        
        //initializes database
        private void InitDatabase()
        {
            //check if file exists
            if (!File.Exists(strDBPath))
            {
                //if it doesnt, create file and set up data tables
                SQLiteConnection.CreateFile(strDBPath);
                //open connection
                using (SQLiteConnection con = new SQLiteConnection($"Data Source={strDBPath};Version=3;"))
                {
                    con.Open();
                    //Businesses
                    //create table
                    string strCreateTableQuery = @"CREATE TABLE IF NOT EXISTS tblBusinesses(
                                                    pkBusiness INTEGER PRIMARY KEY AUTOINCREMENT,
                                                    WordOne TEXT NOT NUll,
                                                    WordTwo TEXT NOT NULL,
                                                    WordThree TEXT NOT NULL
                                                 );";
                    using (SQLiteCommand cmd = new SQLiteCommand(strCreateTableQuery, con))
                    {
                        cmd.ExecuteNonQuery();


                    }
                }
                MessageBox.Show("Table Created");
            }
        }

        //BOAT FUNCTIONS
        public void AddBusiness(string wordOne, string wordTwo, string wordThree)
        {
            //open connection
            using (SQLiteConnection con = new SQLiteConnection($"Data Source={strDBPath};Version=3;"))
            {
                con.Open();
                //create query
                string strInsertQuery = @"INSERT INTO tblBusinesses
                                          (WordOne, WordTwo, WordThree)
                                          VALUES(@wordOne, @wordTwo, @wordThree);";
                using (SQLiteCommand cmd = new SQLiteCommand(strInsertQuery, con))
                {
                    cmd.Parameters.AddWithValue("@wordOne", wordOne);
                    cmd.Parameters.AddWithValue("@wordTwo", wordTwo);
                    cmd.Parameters.AddWithValue("@wordThree", wordThree);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        private void LoadBusinesses(DataGridView dgv)
        {
            //open connection
            using (SQLiteConnection con = new SQLiteConnection($"Data Source={strDBPath};Version=3;"))
            {
                con.Open();

                string strQuery = "SELECT * FROM tblBusinesses;";
                //get and apply data
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(strQuery, con))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgv.DataSource = dt;
                }
            }
            //MessageBox.Show(dgv.DataSource.GetType().ToString());
            //var result = _service.Train("business.txt", dgv.DataSource as DataTable);
            //MessageBox.Show()
            //modelInfoLabel.Text = $"R2: {result.rSquared} MAE: {result.mae}";
        }

        //I know this isnt how u code shit its just easier im sorry
        public void PublicLoadBusinesses()
        {
            LoadBusinesses(businessDGV);
        }
        public bool ValidateWords(string _str, int _numSpaces)
        {
            char[] validationArr = _str.ToCharArray();
            int numSpace = 0;
            for (int i = 0; i < validationArr.Length; i++)
            {
                if (validationArr[i] == ' ')
                {
                    numSpace++;
                }
            }
            if (numSpace == _numSpaces)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public BusinessListForm()
        {
            InitializeComponent();
            //initialize other form
            BusinessDecisionsForm decisionsForm = new BusinessDecisionsForm(this);
            //configure button to navigate to that form
            NavButton newDecisionsPageButton = new NavButton(businessPageButton, decisionsForm, "Help me make business decisions!");

            //initialize other form
            BusinessMergerForm mergerForm = new BusinessMergerForm(this);
            //configure button to navigate to that form
            NavButton newMergerPageButton = new NavButton(mergerPageButton, mergerForm, "Help me handle a merger!");
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            InitDatabase();

            LoadBusinesses(businessDGV);

        }

        private void createIdeaButton_Click(object sender, EventArgs e)
        {
            if (ValidateWords(createIdeaText.Text, 1))
            {
                int space = addBusinessText.Text.IndexOf(' ');
                string wordOne = createIdeaText.Text.Substring(0, space);
                string wordTwo = createIdeaText.Text.Substring(space + 1);

                //string wordThree = _service.Predict(wordOne, wordTwo);

                MessageBox.Show("Try reselling green beans and lettuce to different stores by threatening to short their stocks.");
            }
            else
            {
                MessageBox.Show("Invalid entry. Please read the instructions more closely.");
            }
        }

        private void addBusinessButton_Click(object sender, EventArgs e)
        {
            if (ValidateWords(addBusinessText.Text, 2))
            {
                //parse the business description
                int firstSpace = addBusinessText.Text.IndexOf(' ');
                int secondSpace = addBusinessText.Text.LastIndexOf(' ');

                //first word is all letters before the first space
                string wordOne = addBusinessText.Text.Substring(0, firstSpace);
                //second word is all letters between the two spaces
                string wordTwo = addBusinessText.Text.Substring(firstSpace + 1, secondSpace - firstSpace - 1);
                //third word is all letters efter the last space
                string wordThree = addBusinessText.Text.Substring(secondSpace + 1);

                //add it to the list
                AddBusiness(wordOne, wordTwo, wordThree);
            }
            else
            {
                MessageBox.Show("Invalid entry. Please read the instructions more closely.");
            }




            //end
            LoadBusinesses(businessDGV);
            addBusinessText.Text = string.Empty;
        }
    }
    public class NavButton : Button
    {
        Form toPage;
        Button button;
        public NavButton(Button _button, Form _toPage, string _text)
        {
            _button.AutoSize = true;
            _button.Text = _text;
            _button.Click += NavButton_Click;
            button = _button;
            toPage = _toPage;
        }
        public void NavButton_Click(object sender, EventArgs e)
        {
            button.FindForm().Visible = false;
            toPage.Visible = true;
        }
    }
}
