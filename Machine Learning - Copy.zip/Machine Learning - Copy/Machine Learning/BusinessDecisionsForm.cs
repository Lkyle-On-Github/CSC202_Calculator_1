﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Machine_Learning
{
    public partial class BusinessDecisionsForm : Form
    {
        private RegressionMLService _service = new RegressionMLService();
        //get path
        private string strDBPath = "decisions.db";
        public BusinessDecisionsForm(Form _fromForm)
        {
            InitializeComponent();
            this.Visible = false;
            InitDatabase();
            LoadDecisions(decisionDGV, true);
            NavButton businessListNavButton = new NavButton(businessListButton, _fromForm, "Take me back to the business ideas!");
        }
        private void InitDatabase()
        {
            //check if file exists
            if (!File.Exists(strDBPath))
            {
                //if it doesnt, create file and set up data tables
                SQLiteConnection.CreateFile(strDBPath);
                //open connection
                using (SQLiteConnection con = new SQLiteConnection($"Data Source={strDBPath};Version=3;"))
                {
                    con.Open();
                    //Businesses
                    //create table
                    string strCreateTableQuery = @"CREATE TABLE IF NOT EXISTS tblDecisions(
                                                    pkDecision INTEGER PRIMARY KEY AUTOINCREMENT,
                                                    ShareholderRisk REAL,
                                                    ConsumerRisk REAL,
                                                    RecentPostEngagement REAL,
                                                    StockTrend REAL,
                                                    PotentialProfit REAL,
                                                    TimeOfDay REAL,
                                                    DecisionConfidence REAL
                                                 );";
                    using (SQLiteCommand cmd = new SQLiteCommand(strCreateTableQuery, con))
                    {
                        cmd.ExecuteNonQuery();


                    }
                }
                MessageBox.Show("Table Created");
            }
        }

        //BOAT FUNCTIONS
        private void AddDecision(float shareholderRisk, float consumerRisk, float recentPostEngagement, float stockTrend, float potentialProfit, float timeOfDay, float decisionConfidence)
        {
            //open connection
            using (SQLiteConnection con = new SQLiteConnection($"Data Source={strDBPath};Version=3;"))
            {
                con.Open();
                //create query
                string strInsertQuery = @"INSERT INTO tblDecisions
                                          (ShareholderRisk, ConsumerRisk, RecentPostEngagement, StockTrend, PotentialProfit, TimeOfDay, DecisionConfidence)
                                          VALUES(@shareholderRisk, @consumerRisk, @recentPostEngagement, @stockTrend, @potentialProfit, @timeOfDay, @decisionConfidence);";
                using (SQLiteCommand cmd = new SQLiteCommand(strInsertQuery, con))
                {
                    cmd.Parameters.AddWithValue("@shareholderRisk", shareholderRisk);
                    cmd.Parameters.AddWithValue("@consumerRisk", consumerRisk);
                    cmd.Parameters.AddWithValue("@recentPostEngagement", recentPostEngagement);
                    cmd.Parameters.AddWithValue("@stockTrend", stockTrend);
                    cmd.Parameters.AddWithValue("@potentialProfit", potentialProfit);
                    cmd.Parameters.AddWithValue("@timeOfDay", timeOfDay);
                    cmd.Parameters.AddWithValue("@decisionConfidence", decisionConfidence);
                    cmd.ExecuteNonQuery();
                }
            }
        }
        private void LoadDecisions(DataGridView dgv, bool train)
        {
            //open connection
            using (SQLiteConnection con = new SQLiteConnection($"Data Source={strDBPath};Version=3;"))
            {
                con.Open();

                string strQuery = "SELECT * FROM tblDecisions;";
                //get and apply data
                using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(strQuery, con))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgv.DataSource = dt;
                }
            }
            if (train)
            {
                //MessageBox.Show(dgv.DataSource.GetType().ToString());
                var result = _service.Train("decisions.txt", dgv.DataSource as DataTable);
                //MessageBox.Show()
                modelInfoLabel.Text = $"R2: {result.rSquared} MAE: {result.mae}";
            }
        }
        private void submitButton_Click(object sender, EventArgs e)
        {
            try
            {
                //try to parse the percentages
                float shareRisk = float.Parse(shareRiskBox.Text);
                float conRisk = float.Parse(conRiskBox.Text);
                float eng = float.Parse(engBox.Text);
                //only proceed if they are valid percentages
                //this code does allow negative risk I think but I think thats funny so im allowing it
                if (shareRisk <= 100 && conRisk <= 100 && eng <= 100)
                {
                    float stock = float.Parse(stockBox.Text);
                    float profit = float.Parse(profitBox.Text);
                    float time = float.Parse(dayTimeBox.Text);
                    //having done or not done something is represented as a 0 or 100 confidence rating.
                    float decision = 0;
                    if (decisionCheck.Checked)
                    {
                        decision = 100;
                    }
                    //if all parses passed, add to the list
                    AddDecision(shareRisk, conRisk, eng, stock, profit, time, decision);
                    emptyBoxes();
                    LoadDecisions(decisionDGV, false);
                }
            }
            catch
            {
                MessageBox.Show("invalid number entry!");
            }

        }

        public void emptyBoxes()
        {
            shareRiskBox.Text = "";
            conRiskBox.Text = "";
            engBox.Text = "";
            stockBox.Text = "";
            profitBox.Text = "";
            dayTimeBox.Text = "";
            decisionCheck.Checked = false;
        }

        private void BusinessDecisionsForm_Load(object sender, EventArgs e)
        {
            
        }

        private void rateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //try to parse the percentages
                float shareRisk = float.Parse(shareRiskBox.Text);
                float conRisk = float.Parse(conRiskBox.Text);
                float eng = float.Parse(engBox.Text);
                //only proceed if they are valid percentages
                //this code does allow negative risk I think but I think thats funny so im allowing it
                if (shareRisk <= 100 && conRisk <= 100 && eng <= 100)
                {
                    float stock = float.Parse(stockBox.Text);
                    float profit = float.Parse(profitBox.Text);
                    float time = float.Parse(dayTimeBox.Text);
                    //having done or not done something is represented as a 0 or 100 confidence rating.
                    MessageBox.Show(_service.Predict(shareRisk, conRisk, eng, stock, profit, time));
                    emptyBoxes();
                }
            }
            catch
            {
                MessageBox.Show("invalid number entry!");
            }
        }
    }
}
