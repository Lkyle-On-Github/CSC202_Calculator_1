﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Machine_Learning
{
    public partial class BusinessMergerForm : Form
    {
        BusinessListForm listForm;
        public BusinessMergerForm(Form _fromform)
        {
            listForm = _fromform as BusinessListForm;
            InitializeComponent();
            this.Visible = false;
            NavButton businessListNavButton = new NavButton(businessListButton, _fromform, "Take me back to the business ideas!");

            LayoffAlgo layoffsAlgorithm = new LayoffAlgo(numLayoffsButton, numLayoffsLabel, oNumEmployees, yCompanyWorth, oCompanyWorth);

            WorkloadAlgo workloadAlgorithm = new WorkloadAlgo(workloadButton, workloadLabel, yMonthlySales, oMonthlySales, synergyScore);

            SurviellanceAlgo survAlgorithm = new SurviellanceAlgo(surveillanceButton, surviellanceLabel, buyPrice, synergyScore);

            newMarketAlgo newMarketAlgorithm = new newMarketAlgo(newMarketButton, newMarketLabel, listForm);
        }

        public static void testMethod()
        {
            MessageBox.Show("something hapen");
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }


    }

    public class MergerAlgorithm
    {
        Button button;
        Label label;
        public MergerAlgorithm(Button _button, Label _label)
        {
            button = _button;
            label = _label;

            button.Click += OnClick;

            //update label text with required info
            //Terrible idea
            /*
            label.Text = string.Empty;
            foreach (TextBox textBox in _reqInfo)
            {
                label.Text += textBox.Name;
                label.Text += " ";
            }
            */
        }

        public virtual string Algorithm()
        {
            return "";
        }

        public void OnClick(object sender, EventArgs e)
        {
            MessageBox.Show(Algorithm());
        }
    }

    public class LayoffAlgo : MergerAlgorithm
    {
        TextBox numEmp;
        TextBox yMonSales;
        TextBox oMonSales;
        public LayoffAlgo(Button _button, Label _label, TextBox _oNumEmp, TextBox _yMonSales, TextBox _oMonSales) : base(_button, _label)
        {
            numEmp = _oNumEmp;
            yMonSales = _yMonSales;
            oMonSales = _oMonSales;
        }

        public override string Algorithm()
        {
            try
            {
                float newEmp = float.Parse(numEmp.Text);
                float yourSales = float.Parse(yMonSales.Text);
                float otherSales = float.Parse(oMonSales.Text);

                //divide by zero check
                if (otherSales <= 0)
                {
                    return "fire all the new employees.";
                }

                if (yourSales <= 0)
                {
                    return "Fire all your current employees";
                }

                return String.Concat("fire ", (newEmp / (yourSales / otherSales)).ToString(), " employees.");
            }
            catch
            {
                return "Invalid Data Entry";
            }
        }
    }

    public class WorkloadAlgo : MergerAlgorithm
    {
        TextBox synergy;
        TextBox yMonSales;
        TextBox oMonSales;
        public WorkloadAlgo(Button _button, Label _label, TextBox _yMonSales, TextBox _oMonSales, TextBox _synergy) : base(_button, _label)
        {
            synergy = _synergy;
            yMonSales = _yMonSales;
            oMonSales = _oMonSales;
        }

        public override string Algorithm()
        {
            try
            {
                float synPerc = float.Parse(synergy.Text);
                float yourSales = float.Parse(yMonSales.Text);
                float otherSales = float.Parse(oMonSales.Text);

                float result = yourSales - (otherSales * (synPerc / 100));
                if (result > 0)
                {
                    return String.Concat("Adjust workload for all employees by +", result.ToString(), "%");
                }
                else
                {
                    return String.Concat("Adjust workload for all employees by ", result.ToString(), "%");
                }
            }
            catch
            {
                return "Invalid Data Entry";
            }
        }
    }

    public class SurviellanceAlgo : MergerAlgorithm
    {
        TextBox synergy;
        TextBox buyPrice;
        public SurviellanceAlgo(Button _button, Label _label, TextBox _buyPrice, TextBox _synergy) : base(_button, _label)
        {
            synergy = _synergy;
            buyPrice = _buyPrice;
        }

        public override string Algorithm()
        {
            try
            {
                float synPerc = float.Parse(synergy.Text);
                float price = float.Parse(buyPrice.Text);
                if (synPerc >= 0)
                {
                    return "You must find a way to synergize them or the company is doomed!";
                }
                return string.Concat("Start surveillance on at least ", (price / (synPerc / 100)).ToString(), " Immediately!!!");

            }
            catch
            {
                return "Invalid Data Entry";
            }
        }
    }

    public class newMarketAlgo : MergerAlgorithm
    {
        BusinessListForm listForm;
        public newMarketAlgo(Button _button, Label _label, BusinessListForm _listForm) : base(_button, _label)
        {
            listForm = _listForm;
        }

        public override string Algorithm()
        {
            listForm.AddBusiness("Bagged", "Pizza", "Drive-thru");
            listForm.PublicLoadBusinesses();
            MessageBox.Show("Your new product market should be: Bagged Pizza Drive-Thru");
            return "Bagged Pizza Drive-Thru has been added to the list of successful businesses.";
        }
    }
}
