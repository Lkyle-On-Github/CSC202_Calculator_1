﻿namespace Machine_Learning
{
    partial class BusinessMergerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            businessListButton = new Button();
            pageLabel = new Label();
            entryLabel = new Label();
            outputLabel = new Label();
            yNumEmployees = new TextBox();
            oNumEmployees = new TextBox();
            yourCompanyLabel = new Label();
            otherCompanyLabel = new Label();
            oCompanyWorth = new TextBox();
            yCompanyWorth = new TextBox();
            label1 = new Label();
            buyPrice = new TextBox();
            synergyScore = new TextBox();
            numLayoffsButton = new Button();
            workloadButton = new Button();
            newMarketButton = new Button();
            yMonthlySales = new TextBox();
            oMonthlySales = new TextBox();
            numLayoffsLabel = new Label();
            workloadLabel = new Label();
            newMarketLabel = new Label();
            surveillanceButton = new Button();
            surviellanceLabel = new Label();
            SuspendLayout();
            // 
            // businessListButton
            // 
            businessListButton.Location = new Point(338, 442);
            businessListButton.Name = "businessListButton";
            businessListButton.Size = new Size(94, 29);
            businessListButton.TabIndex = 1;
            businessListButton.Text = "button1";
            businessListButton.UseVisualStyleBackColor = true;
            // 
            // pageLabel
            // 
            pageLabel.AutoSize = true;
            pageLabel.Location = new Point(207, 9);
            pageLabel.Name = "pageLabel";
            pageLabel.Size = new Size(395, 20);
            pageLabel.TabIndex = 2;
            pageLabel.Text = "Use Advanced Algorithms to successfully handle a merger!";
            // 
            // entryLabel
            // 
            entryLabel.AutoSize = true;
            entryLabel.Location = new Point(272, 51);
            entryLabel.Name = "entryLabel";
            entryLabel.Size = new Size(286, 20);
            entryLabel.TabIndex = 3;
            entryLabel.Text = "Enter info about the merging companies...";
            // 
            // outputLabel
            // 
            outputLabel.AutoSize = true;
            outputLabel.Location = new Point(239, 253);
            outputLabel.Name = "outputLabel";
            outputLabel.Size = new Size(347, 20);
            outputLabel.TabIndex = 4;
            outputLabel.Text = "and get helpful suggestions based on your request!";
            // 
            // yNumEmployees
            // 
            yNumEmployees.Location = new Point(21, 136);
            yNumEmployees.Name = "yNumEmployees";
            yNumEmployees.PlaceholderText = "Num Employees";
            yNumEmployees.Size = new Size(116, 27);
            yNumEmployees.TabIndex = 5;
            // 
            // oNumEmployees
            // 
            oNumEmployees.Location = new Point(433, 135);
            oNumEmployees.Name = "oNumEmployees";
            oNumEmployees.PlaceholderText = "Num Employees";
            oNumEmployees.Size = new Size(116, 27);
            oNumEmployees.TabIndex = 6;
            // 
            // yourCompanyLabel
            // 
            yourCompanyLabel.AutoSize = true;
            yourCompanyLabel.Location = new Point(151, 76);
            yourCompanyLabel.Name = "yourCompanyLabel";
            yourCompanyLabel.Size = new Size(106, 20);
            yourCompanyLabel.TabIndex = 7;
            yourCompanyLabel.Text = "Your company:";
            // 
            // otherCompanyLabel
            // 
            otherCompanyLabel.AutoSize = true;
            otherCompanyLabel.Location = new Point(555, 77);
            otherCompanyLabel.Name = "otherCompanyLabel";
            otherCompanyLabel.Size = new Size(114, 20);
            otherCompanyLabel.TabIndex = 8;
            otherCompanyLabel.Text = "Other company:";
            // 
            // oCompanyWorth
            // 
            oCompanyWorth.Location = new Point(555, 135);
            oCompanyWorth.Name = "oCompanyWorth";
            oCompanyWorth.PlaceholderText = "Company Worth";
            oCompanyWorth.Size = new Size(116, 27);
            oCompanyWorth.TabIndex = 9;
            // 
            // yCompanyWorth
            // 
            yCompanyWorth.Location = new Point(141, 136);
            yCompanyWorth.Name = "yCompanyWorth";
            yCompanyWorth.PlaceholderText = "Company Worth";
            yCompanyWorth.Size = new Size(116, 27);
            yCompanyWorth.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(321, 178);
            label1.Name = "label1";
            label1.Size = new Size(185, 20);
            label1.TabIndex = 11;
            label1.Text = "some info about the deal...";
            // 
            // buyPrice
            // 
            buyPrice.Location = new Point(275, 223);
            buyPrice.Name = "buyPrice";
            buyPrice.PlaceholderText = "Buy Price";
            buyPrice.Size = new Size(116, 27);
            buyPrice.TabIndex = 12;
            // 
            // synergyScore
            // 
            synergyScore.Location = new Point(422, 223);
            synergyScore.Name = "synergyScore";
            synergyScore.PlaceholderText = "Synergy Score (%)";
            synergyScore.Size = new Size(127, 27);
            synergyScore.TabIndex = 13;
            // 
            // numLayoffsButton
            // 
            numLayoffsButton.Location = new Point(21, 284);
            numLayoffsButton.Name = "numLayoffsButton";
            numLayoffsButton.Size = new Size(165, 54);
            numLayoffsButton.TabIndex = 14;
            numLayoffsButton.Text = "How many employees should I lay off?";
            numLayoffsButton.UseVisualStyleBackColor = true;
            // 
            // workloadButton
            // 
            workloadButton.Location = new Point(192, 284);
            workloadButton.Name = "workloadButton";
            workloadButton.Size = new Size(178, 54);
            workloadButton.TabIndex = 15;
            workloadButton.Text = "How should I adjust my employee workload?";
            workloadButton.UseVisualStyleBackColor = true;
            // 
            // newMarketButton
            // 
            newMarketButton.Location = new Point(626, 284);
            newMarketButton.Name = "newMarketButton";
            newMarketButton.Size = new Size(167, 54);
            newMarketButton.TabIndex = 16;
            newMarketButton.Text = "What should our new product market be?";
            newMarketButton.UseVisualStyleBackColor = true;
            // 
            // yMonthlySales
            // 
            yMonthlySales.Location = new Point(263, 136);
            yMonthlySales.Name = "yMonthlySales";
            yMonthlySales.PlaceholderText = "Monthly Sales";
            yMonthlySales.Size = new Size(116, 27);
            yMonthlySales.TabIndex = 17;
            // 
            // oMonthlySales
            // 
            oMonthlySales.Location = new Point(677, 135);
            oMonthlySales.Name = "oMonthlySales";
            oMonthlySales.PlaceholderText = "Monthly Sales";
            oMonthlySales.Size = new Size(116, 27);
            oMonthlySales.TabIndex = 18;
            // 
            // numLayoffsLabel
            // 
            numLayoffsLabel.AutoSize = true;
            numLayoffsLabel.Location = new Point(43, 342);
            numLayoffsLabel.Name = "numLayoffsLabel";
            numLayoffsLabel.Size = new Size(117, 60);
            numLayoffsLabel.TabIndex = 19;
            numLayoffsLabel.Text = "Required Info:\r\nNum employees\r\nCompany Worth";
            numLayoffsLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // workloadLabel
            // 
            workloadLabel.AutoSize = true;
            workloadLabel.Location = new Point(239, 342);
            workloadLabel.Name = "workloadLabel";
            workloadLabel.Size = new Size(102, 60);
            workloadLabel.TabIndex = 20;
            workloadLabel.Text = "Required Info:\r\nMonthly Sales\r\nSynergy Score";
            workloadLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // newMarketLabel
            // 
            newMarketLabel.AutoSize = true;
            newMarketLabel.Location = new Point(635, 342);
            newMarketLabel.Name = "newMarketLabel";
            newMarketLabel.Size = new Size(142, 40);
            newMarketLabel.TabIndex = 21;
            newMarketLabel.Text = "Required Info:\r\nany amount is fine :)\r\n";
            newMarketLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // surveillanceButton
            // 
            surveillanceButton.Location = new Point(372, 284);
            surveillanceButton.Name = "surveillanceButton";
            surveillanceButton.Size = new Size(248, 54);
            surveillanceButton.TabIndex = 22;
            surveillanceButton.Text = "How many new employees should be put under Surviellance?";
            surveillanceButton.UseVisualStyleBackColor = true;
            // 
            // surviellanceLabel
            // 
            surviellanceLabel.AutoSize = true;
            surviellanceLabel.Location = new Point(447, 342);
            surviellanceLabel.Name = "surviellanceLabel";
            surviellanceLabel.Size = new Size(102, 60);
            surviellanceLabel.TabIndex = 23;
            surviellanceLabel.Text = "Required Info:\r\nBuy price\r\nSynergy Score";
            surviellanceLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // BusinessMergerForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 483);
            Controls.Add(surviellanceLabel);
            Controls.Add(surveillanceButton);
            Controls.Add(newMarketLabel);
            Controls.Add(workloadLabel);
            Controls.Add(numLayoffsLabel);
            Controls.Add(oMonthlySales);
            Controls.Add(yMonthlySales);
            Controls.Add(newMarketButton);
            Controls.Add(workloadButton);
            Controls.Add(numLayoffsButton);
            Controls.Add(synergyScore);
            Controls.Add(buyPrice);
            Controls.Add(label1);
            Controls.Add(yCompanyWorth);
            Controls.Add(oCompanyWorth);
            Controls.Add(otherCompanyLabel);
            Controls.Add(yourCompanyLabel);
            Controls.Add(oNumEmployees);
            Controls.Add(yNumEmployees);
            Controls.Add(outputLabel);
            Controls.Add(entryLabel);
            Controls.Add(pageLabel);
            Controls.Add(businessListButton);
            Name = "BusinessMergerForm";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button businessListButton;
        private Label pageLabel;
        private Label entryLabel;
        private Label outputLabel;
        private TextBox yNumEmployees;
        private TextBox oNumEmployees;
        private Label yourCompanyLabel;
        private Label otherCompanyLabel;
        private TextBox oCompanyWorth;
        private TextBox yCompanyWorth;
        private Label label1;
        private TextBox buyPrice;
        private TextBox synergyScore;
        private Button numLayoffsButton;
        private Button workloadButton;
        private Button newMarketButton;
        private TextBox yMonthlySales;
        private TextBox oMonthlySales;
        private Label numLayoffsLabel;
        private Label workloadLabel;
        private Label newMarketLabel;
        private Button surveillanceButton;
        private Label surviellanceLabel;
    }
}