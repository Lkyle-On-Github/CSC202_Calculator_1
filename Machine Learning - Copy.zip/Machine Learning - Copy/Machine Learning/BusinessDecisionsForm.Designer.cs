﻿namespace Machine_Learning
{
    partial class BusinessDecisionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            categoryOneLabel = new Label();
            categoryTwoLabel = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            shareRiskBox = new TextBox();
            conRiskBox = new TextBox();
            engBox = new TextBox();
            stockBox = new TextBox();
            profitBox = new TextBox();
            dayTimeBox = new TextBox();
            submitButton = new Button();
            decisionDGV = new DataGridView();
            decisionCheck = new CheckBox();
            rateButton = new Button();
            modelInfoLabel = new Label();
            businessListButton = new Button();
            ((System.ComponentModel.ISupportInitialize)decisionDGV).BeginInit();
            SuspendLayout();
            // 
            // categoryOneLabel
            // 
            categoryOneLabel.AutoSize = true;
            categoryOneLabel.Location = new Point(118, 35);
            categoryOneLabel.Name = "categoryOneLabel";
            categoryOneLabel.Size = new Size(168, 20);
            categoryOneLabel.TabIndex = 0;
            categoryOneLabel.Text = "enter info (percentages)";
            // 
            // categoryTwoLabel
            // 
            categoryTwoLabel.AutoSize = true;
            categoryTwoLabel.Location = new Point(515, 35);
            categoryTwoLabel.Name = "categoryTwoLabel";
            categoryTwoLabel.Size = new Size(134, 20);
            categoryTwoLabel.TabIndex = 1;
            categoryTwoLabel.Text = "enter info (Dollars)";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(724, 35);
            label1.Name = "label1";
            label1.Size = new Size(123, 20);
            label1.TabIndex = 2;
            label1.Text = "enter time of day";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 91);
            label2.Name = "label2";
            label2.Size = new Size(119, 20);
            label2.TabIndex = 3;
            label2.Text = "Shareholder Risk";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(137, 91);
            label3.Name = "label3";
            label3.Size = new Size(105, 20);
            label3.TabIndex = 4;
            label3.Text = "Consumer Risk";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(248, 91);
            label4.Name = "label4";
            label4.Size = new Size(173, 20);
            label4.TabIndex = 5;
            label4.Text = "Recent Post Engagement";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(465, 91);
            label5.Name = "label5";
            label5.Size = new Size(86, 20);
            label5.TabIndex = 6;
            label5.Text = "Stock Trend";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(593, 91);
            label6.Name = "label6";
            label6.Size = new Size(107, 20);
            label6.TabIndex = 7;
            label6.Text = "Potential Profit";
            // 
            // shareRiskBox
            // 
            shareRiskBox.Location = new Point(33, 114);
            shareRiskBox.MaxLength = 3;
            shareRiskBox.Name = "shareRiskBox";
            shareRiskBox.Size = new Size(64, 27);
            shareRiskBox.TabIndex = 9;
            // 
            // conRiskBox
            // 
            conRiskBox.Location = new Point(152, 114);
            conRiskBox.MaxLength = 3;
            conRiskBox.Name = "conRiskBox";
            conRiskBox.Size = new Size(64, 27);
            conRiskBox.TabIndex = 10;
            // 
            // engBox
            // 
            engBox.Location = new Point(307, 114);
            engBox.MaxLength = 3;
            engBox.Name = "engBox";
            engBox.Size = new Size(64, 27);
            engBox.TabIndex = 11;
            // 
            // stockBox
            // 
            stockBox.Location = new Point(459, 114);
            stockBox.MaxLength = 16;
            stockBox.Name = "stockBox";
            stockBox.Size = new Size(92, 27);
            stockBox.TabIndex = 12;
            // 
            // profitBox
            // 
            profitBox.Location = new Point(600, 114);
            profitBox.MaxLength = 16;
            profitBox.Name = "profitBox";
            profitBox.Size = new Size(92, 27);
            profitBox.TabIndex = 13;
            // 
            // dayTimeBox
            // 
            dayTimeBox.Location = new Point(742, 114);
            dayTimeBox.MaxLength = 4;
            dayTimeBox.Name = "dayTimeBox";
            dayTimeBox.Size = new Size(92, 27);
            dayTimeBox.TabIndex = 14;
            // 
            // submitButton
            // 
            submitButton.Location = new Point(307, 172);
            submitButton.Name = "submitButton";
            submitButton.Size = new Size(189, 29);
            submitButton.TabIndex = 15;
            submitButton.Text = "Submit Past Decision";
            submitButton.UseVisualStyleBackColor = true;
            submitButton.Click += submitButton_Click;
            // 
            // decisionDGV
            // 
            decisionDGV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            decisionDGV.Location = new Point(12, 207);
            decisionDGV.Name = "decisionDGV";
            decisionDGV.RowHeadersWidth = 51;
            decisionDGV.Size = new Size(958, 188);
            decisionDGV.TabIndex = 16;
            // 
            // decisionCheck
            // 
            decisionCheck.AutoSize = true;
            decisionCheck.Location = new Point(858, 117);
            decisionCheck.Name = "decisionCheck";
            decisionCheck.Size = new Size(125, 24);
            decisionCheck.TabIndex = 19;
            decisionCheck.Text = "Did you do it?";
            decisionCheck.UseVisualStyleBackColor = true;
            // 
            // rateButton
            // 
            rateButton.Location = new Point(502, 172);
            rateButton.Name = "rateButton";
            rateButton.Size = new Size(189, 29);
            rateButton.TabIndex = 20;
            rateButton.Text = "Rate Potential Decision";
            rateButton.UseVisualStyleBackColor = true;
            rateButton.Click += rateButton_Click;
            // 
            // modelInfoLabel
            // 
            modelInfoLabel.AutoSize = true;
            modelInfoLabel.Location = new Point(783, 176);
            modelInfoLabel.Name = "modelInfoLabel";
            modelInfoLabel.Size = new Size(0, 20);
            modelInfoLabel.TabIndex = 22;
            // 
            // businessListButton
            // 
            businessListButton.Location = new Point(372, 409);
            businessListButton.Name = "businessListButton";
            businessListButton.Size = new Size(94, 29);
            businessListButton.TabIndex = 23;
            businessListButton.Text = "button1";
            businessListButton.UseVisualStyleBackColor = true;
            // 
            // BusinessDecisionsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 450);
            Controls.Add(businessListButton);
            Controls.Add(modelInfoLabel);
            Controls.Add(rateButton);
            Controls.Add(decisionCheck);
            Controls.Add(decisionDGV);
            Controls.Add(submitButton);
            Controls.Add(dayTimeBox);
            Controls.Add(profitBox);
            Controls.Add(stockBox);
            Controls.Add(engBox);
            Controls.Add(conRiskBox);
            Controls.Add(shareRiskBox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(categoryTwoLabel);
            Controls.Add(categoryOneLabel);
            Name = "BusinessDecisionsForm";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)decisionDGV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label categoryOneLabel;
        private Label categoryTwoLabel;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox shareRiskBox;
        private TextBox conRiskBox;
        private TextBox engBox;
        private TextBox stockBox;
        private TextBox profitBox;
        private TextBox dayTimeBox;
        private Button submitButton;
        private DataGridView decisionDGV;
        private CheckBox decisionCheck;
        private Button rateButton;
        private Label modelInfoLabel;
        private Button businessListButton;
    }
}