﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Microsoft.ML;
using Microsoft.ML.Data;
using System.IO;

namespace Machine_Learning
{
    public class ML
    {

    }

    public class BusinessIdea
    {
        [LoadColumn(0)]
        public float shareholderRisk { get; set; }

        [LoadColumn(1)]

        public float consumerRisk { get; set; }

        [LoadColumn(2)]

        public float recentPostEngagement { get; set; }

        [LoadColumn(3)]

        public float stockTrend { get; set; }

        [LoadColumn(4)]

        public float potentialProfit { get; set; }

        [LoadColumn(5)]

        public float timeOfDay { get; set; }

        [LoadColumn(6)]

        public float decisionConfidence { get; set; }
    }

    public class BusinessPrediction
    {
        [ColumnName("Score")]

        public float predictedDecisionConfidence { get; set; }

    }

    public class RegressionMLService
    {
        private readonly MLContext _mlContext;

        private PredictionEngine<BusinessIdea, BusinessPrediction> _engine;

        public bool IsReady => _engine != null;

        public RegressionMLService()
        {
            _mlContext = new MLContext(seed: 42);
        }

        public (double rSquared, double mae) Train(string dataPath, DataTable data)
        {
            using (StreamWriter sw = new StreamWriter(dataPath))
            {
                sw.WriteLine("wordOne,wordTwo,wordThree");
                foreach (DataRow row in data.Rows)
                {
                    sw.Write(row[1]);
                    sw.Write(",");
                    sw.Write(row[2]);
                    sw.Write(",");
                    sw.Write(row[3]);
                    sw.Write(",");
                    sw.Write(row[4]);
                    sw.Write(",");
                    sw.Write(row[5]);
                    sw.Write(",");
                    sw.Write(row[6]);
                    sw.Write(",");
                    sw.Write("\r\n");
                }
                //sw.Close();
            }

            //MessageBox.Show("Pause");
            //IDataView dataView = data.
            
            IDataView dataView = _mlContext.Data.LoadFromTextFile<BusinessIdea>(
                    path: dataPath,
                    hasHeader: true,
                    separatorChar: ','
                );

           
            var pipeline = _mlContext.Transforms.Concatenate("Features",
            nameof(BusinessIdea.shareholderRisk),
            nameof(BusinessIdea.consumerRisk),
            nameof(BusinessIdea.recentPostEngagement),
            nameof(BusinessIdea.stockTrend),
            nameof(BusinessIdea.potentialProfit),
            nameof(BusinessIdea.timeOfDay)
            )
                .Append(_mlContext.Transforms.NormalizeMinMax("Features"))
                .Append(_mlContext.Regression.Trainers.Sdca(
                    labelColumnName: nameof(BusinessIdea.decisionConfidence),
                    featureColumnName: "Features"
                    ));

            var model = pipeline.Fit(dataView);

            var predictions = model.Transform(dataView);

            var metrics = _mlContext.Regression.Evaluate(
                predictions,
                labelColumnName: nameof(BusinessIdea.decisionConfidence)
                );

            _engine = _mlContext.Model.CreatePredictionEngine<BusinessIdea, BusinessPrediction>(model);

            return (
                Math.Round(metrics.RSquared, 3),
                Math.Round(metrics.MeanAbsoluteError, 2)
                );
        }

        public string Predict(float _shareholderRisk, float _consumerRisk, float _recentPostEngagement, float _stockTrend, float _potentialProfit, float _timeOfDay)
        {
            if(!IsReady)
            {
                throw new InvalidOperationException("Model not ready.");
            }

            var input = new BusinessIdea
            {
                shareholderRisk = _shareholderRisk,
                consumerRisk = _consumerRisk,
                recentPostEngagement = _recentPostEngagement,
                stockTrend = _stockTrend,
                potentialProfit = _potentialProfit,
                timeOfDay = _timeOfDay
            };

            return _engine.Predict(input).predictedDecisionConfidence.ToString();
        }

    }

   


}
