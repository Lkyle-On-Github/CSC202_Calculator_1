using System.Diagnostics;
using System.Security.Cryptography;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;

namespace AssertTest
{
    public partial class assertForm : Form
    {
        public assertForm()
        {
            InitializeComponent();
        }

        
        private void submitButton_Click(object sender, EventArgs e)
        {
            Debug.Assert(IsUpper());
            label1.Text = textBox1.Text;
            Debug.Assert(HasVowel());
            label2.Text = textBox2.Text;
        }
        
        private bool IsUpper()
        {
            if (textBox1.Text.ToUpper() == textBox1.Text)
            {
                return true;
            }
            return false;
        }

        private bool HasVowel()
        {
            //vowels are:
            char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
            //aeiou
            foreach (char vowel in vowels)
            {
                if (textBox2.Text.ToLower().Contains(vowel))
                {
                    return true;
                }
            }
            //and sometimes y
            if (textBox2.Text.ToLower().Contains('y') && RandomNumberGenerator.GetInt32(2) == 0)
            {
                return true;
            }
            return false;
        }


    }
}
