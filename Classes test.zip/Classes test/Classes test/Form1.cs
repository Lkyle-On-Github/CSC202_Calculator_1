namespace Classes_test
{
    public partial class Form1 : Form
    {
        CaveInfo[] caveList;
        int currIndex;
        public Form1()
        {
            InitializeComponent();
            currIndex = -1;
            caveList = new CaveInfo[0];
            UpdateView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //create reference to new cave
            CaveInfo newCave = new CaveInfo();
            //get the info from the user entry
            string[] newInfo = FindCave();
            //set the cave class' values
            if(newCave.SetCave(newInfo[0], newInfo[1], newInfo[2], newInfo[3], newInfo[4], newInfo[5]))
            {
                //if successful, add the new cave.
                    //I swear you could just use append for this, cant find it in the documentation for some reason
                    //caveList = caveList.Append(newCave);
                CaveInfo[] caveListBackup = caveList;
                caveList = new CaveInfo[caveList.Length + 1];
                caveListBackup.CopyTo(caveList, 0);
                caveList[caveList.Length - 1] = newCave;
                
                nameBox.Text = "";
                statusBox.Text = "";
                locationBox.Text  = "";
                coordinateBox.Text = "";
                entranceBox.Text = "";
                deepestBox.Text = "";
                //if this is the first cave added, display it now;
                if (currIndex == -1)
                {
                    currIndex = 0;
                    string[] currCave = caveList[currIndex].GetCave();
                    viewNameLabel.Text = currCave[0];
                    viewStatusLabel.Text = currCave[1];
                    viewLocationLabel.Text = currCave[2];
                    viewEntranceLabel.Text = currCave[3];
                    viewDeepestLabel.Text = currCave[4];
                }
                UpdateView();
            }
            
        }
        

        //shouldnt need to check validation on these cuz the buttons are only enabled if valid
        private void leftButton_Click(object sender, EventArgs e)
        {
            currIndex -= 1;
            viewButton();
        }

        private void rightButton_Click(object sender, EventArgs e)
        {
            currIndex += 1;
            viewButton();
        }

        //assumes that the index was updated by the button function
        private void viewButton()
        {
            UpdateView();
            string[] currCave = caveList[currIndex].GetCave();
            viewNameLabel.Text = currCave[0];
            viewStatusLabel.Text = currCave[1];
            viewLocationLabel.Text = currCave[2];
            viewEntranceLabel.Text = currCave[3];
            viewDeepestLabel.Text = currCave[4];
        }

        //gets the cave from the text box values
        private string[] FindCave()
        {
            return new string[] { nameBox.Text, statusBox.Text, locationBox.Text, coordinateBox.Text, entranceBox.Text, deepestBox.Text };
        }
        private void UpdateView()
        {
            //enable the left button only if going back in the array is possible
            if (currIndex <= 0)
            {
                leftButton.Enabled = false;
            }
            else
            {
                leftButton.Enabled = true;
            }
            //enable the right button only if moving forward in the array is possible
            if (currIndex == caveList.Length - 1 || caveList.Length == 0)
            {
                rightButton.Enabled = false;
            }
            else
            {
                rightButton.Enabled = true;
            }
            //change the text between the buttons to display current position in the list of saved caves
            viewingLabel.Text = string.Concat((currIndex + 1).ToString(), "/", caveList.Length.ToString());
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }

    public class CaveInfo
    {
        string name;
        string location;
        string explStatus;
        float entranceDepth;
        float deepestDepth;
        public CaveInfo()
        {
            name = string.Empty;
            location = string.Empty;
            explStatus = string.Empty;
        }

        public bool SetCave(string newName, string newStatus, string newLocation, string newCoordinates, string newEntrance, string newDeepest)
        {
            if (!string.IsNullOrEmpty(newName) && !string.IsNullOrEmpty(newStatus) && !string.IsNullOrEmpty(newLocation) && !string.IsNullOrEmpty(newEntrance) && !string.IsNullOrEmpty(newDeepest))
            {
                bool checkCoords = false;
                try
                {
                    entranceDepth = float.Parse(newEntrance);
                    deepestDepth = float.Parse(newDeepest);
                    name = newName;
                    location = newLocation;
                    //add coordinates to the end of the location
                    if (newCoordinates != string.Empty && newCoordinates != "")
                    {
                        location = string.Concat(location, "\r\n", newCoordinates);
                        //since coords were entered, they must be checked.
                        checkCoords = true;
                    }
                    explStatus = newStatus;
                }
                catch
                {

                    MessageBox.Show("invalid number entry!");
                    return false;
                }
                if (checkCoords)
                {
                    //check if the coordinates were entered correctly
                    try
                    {
                        //get the index of the space
                        int spacePos = newCoordinates.IndexOf(' ');
                        //first coordinate is everything before the space
                        float firstCoord = float.Parse(newCoordinates.Substring(0, spacePos));
                        float secondCoord = float.Parse(newCoordinates.Substring(spacePos + 1));
                    }
                    catch
                    {

                        MessageBox.Show("Coordinates should be entered as two numbers with a space between them");
                        return false;
                    }
                }
                //no errors, return true!
                return true;
            } else
            {
                MessageBox.Show("Please enter text in all the non optional fields (top row)");
                return false; 
            }
        }
        public string[] GetCave()
        {
            return new string[] { name, explStatus, location, entranceDepth.ToString(), deepestDepth.ToString() };
        }
    }


}
