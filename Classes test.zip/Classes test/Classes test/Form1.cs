using System.Dynamic;
using System.Xml.Linq;

namespace Classes_test
{
    public partial class Form1 : Form
    {
        CaveInfo[] caveList;
        int currIndex;
        public Form1()
        {
            InitializeComponent();
            currIndex = -1;
            caveList = new CaveInfo[0];
            UpdateView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //create reference to new cave
            CaveInfo newCave = new CaveInfo();
            //get the info from the user entry
            string[] newInfo = FindCave();
            //set the cave class' values
            if (newCave.SetCave(newInfo[0], newInfo[1], newInfo[2], newInfo[3], newInfo[4], newInfo[5]))
            {
                //if successful, add the new cave.
                //I swear you could just use append for this, cant find it in the documentation for some reason
                //caveList = caveList.Append(newCave);
                CaveInfo[] caveListBackup = caveList;
                caveList = new CaveInfo[caveList.Length + 1];
                caveListBackup.CopyTo(caveList, 0);
                caveList[caveList.Length - 1] = newCave;
                newCave.caveIndex = caveList.Length - 1;
                nameBox.Text = "";
                statusBox.Text = "";
                locationBox.Text = "";
                coordinateBox.Text = "";
                entranceBox.Text = "";
                deepestBox.Text = "";
                //if this is the first cave added, display it now;
                if (currIndex == -1)
                {
                    currIndex = 0;
                    UpdateViewInfo();
                }
                UpdateView();
            }

        }


        //shouldnt need to check validation on these cuz the buttons are only enabled if valid
        private void leftButton_Click(object sender, EventArgs e)
        {
            currIndex -= 1;
            viewButton();
        }

        private void rightButton_Click(object sender, EventArgs e)
        {
            currIndex += 1;
            viewButton();
        }

        //assumes that the index was updated by the button function
        private void viewButton()
        {
            UpdateView();
            UpdateViewInfo();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            caveList[currIndex] = caveList[currIndex].AddInfo(newEntranceBox.Text, InaccessibleCheck.Checked);
            UpdateViewInfo();
        }

        private void DisplayAllButton_Click_2(object sender, EventArgs e)
        {
            caveList[currIndex].Display();
        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {
            try
            {
                caveList[currIndex].Display(int.Parse(displayNumBox.Text));
            } catch
            {
                MessageBox.Show("Please enter an integer!");
            }
        }

        //gets the cave from the text box values
        private string[] FindCave()
        {
            return new string[] { nameBox.Text, statusBox.Text, locationBox.Text, coordinateBox.Text, entranceBox.Text, deepestBox.Text };
        }
        private void UpdateView()
        {
            //enable the left button only if going back in the array is possible
            if (currIndex <= 0)
            {
                leftButton.Enabled = false;
            }
            else
            {
                leftButton.Enabled = true;
            }
            //enable the right button only if moving forward in the array is possible
            if (currIndex == caveList.Length - 1 || caveList.Length == 0)
            {
                rightButton.Enabled = false;
            }
            else
            {
                rightButton.Enabled = true;
            }
            //change the text between the buttons to display current position in the list of saved caves
            viewingLabel.Text = string.Concat((currIndex + 1).ToString(), "/", caveList.Length.ToString());
        }

        private void UpdateViewInfo()
        {
            string[] currCave = caveList[currIndex].GetCave();
            viewNameLabel.Text = currCave[0];
            viewStatusLabel.Text = currCave[1];
            viewLocationLabel.Text = currCave[2];
            viewEntranceLabel.Text = currCave[3];
            viewDeepestLabel.Text = currCave[4];
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }


    }

    public class CaveInfo
    {
        string name;
        string location;
        string explStatus;
        float entranceDepth;
        float deepestDepth;
        public int caveIndex = 0;
        public CaveInfo()
        {
            name = string.Empty;
            location = string.Empty;
            explStatus = string.Empty;
        }

        public bool SetCave(string newName, string newStatus, string newLocation, string newCoordinates, string newEntrance, string newDeepest)
        {
            if (!string.IsNullOrEmpty(newName) && !string.IsNullOrEmpty(newStatus) && !string.IsNullOrEmpty(newLocation) && !string.IsNullOrEmpty(newEntrance) && !string.IsNullOrEmpty(newDeepest))
            {
                bool checkCoords = false;
                try
                {
                    entranceDepth = float.Parse(newEntrance);
                    deepestDepth = float.Parse(newDeepest);
                    name = newName;
                    location = newLocation;
                    //add coordinates to the end of the location
                    if (newCoordinates != string.Empty && newCoordinates != "")
                    {
                        location = string.Concat(location, "\r\n", newCoordinates);
                        //since coords were entered, they must be checked.
                        checkCoords = true;
                    }
                    explStatus = newStatus;
                }
                catch
                {

                    MessageBox.Show("invalid number entry!");
                    return false;
                }
                if (checkCoords)
                {
                    //check if the coordinates were entered correctly
                    try
                    {
                        //get the index of the space
                        int spacePos = newCoordinates.IndexOf(' ');
                        //first coordinate is everything before the space
                        float firstCoord = float.Parse(newCoordinates.Substring(0, spacePos));
                        float secondCoord = float.Parse(newCoordinates.Substring(spacePos + 1));
                    }
                    catch
                    {

                        MessageBox.Show("Coordinates should be entered as two numbers with a space between them");
                        return false;
                    }
                }
                //no errors, return true!
                return true;
            } else
            {
                MessageBox.Show("Please enter text in all the non optional fields (top row)");
                return false; 
            }
        }
        public string[] GetCave()
        {
            return new string[] { name, explStatus, location, GetEntrance(), deepestDepth.ToString() };
        }

        public void Display()
        {
            string[] info = new string[] { name, explStatus, location, GetEntrance(), deepestDepth.ToString() };
            foreach (string str in info)
            {
                MessageBox.Show(str);
            }
        }

        public void Display(int displayNum)
        {
            string[] info = new string[] { name, explStatus, location, GetEntrance(), deepestDepth.ToString() };
            for (int i = 0; i < info.Length && i < displayNum; i++)
            {
                MessageBox.Show(info[i]);
            }
        }
        public virtual string GetEntrance()
        {
            return entranceDepth.ToString();
        }

        public virtual CaveInfo AddInfo(string newInfo, bool inaccessible)
        {
            if(!inaccessible)
            {
                if (newInfo != "")
                {
                    //convert to multiple entrances
                    //create the new instnace
                    CaveInfoMultipleEntrances updatedCave = new CaveInfoMultipleEntrances(entranceDepth);
                    //fill the info
                    updatedCave.SetCave(name, explStatus, location, "", entranceDepth.ToString(), deepestDepth.ToString());
                    //add the new info
                    updatedCave.AddInfo(newInfo, inaccessible);
                    return updatedCave;

                } else
                {
                    //return the unmodified cavelist
                    MessageBox.Show("No new info was entered!");
                    return this;
                }
            } else
            {
                //convert to inacessable
                //create the instance
                CaveInfoInaccessable updatedCave = new CaveInfoInaccessable();
                //fill the info
                updatedCave.SetCave(name, explStatus, location, "", entranceDepth.ToString(), deepestDepth.ToString());
                //no info is added when converted to inaccessible, skip this step
                return updatedCave;
            }
        }
    }

    //PLAN
    /*
     two new classes are: multiple entrances, inaccessible
     */
    public class CaveInfoMultipleEntrances : CaveInfo
    {
        float[] entrances = new float[1];

        public CaveInfoMultipleEntrances(float entrance)
        {
            entrances[0] = entrance;
        }
        public override string GetEntrance()
        {
            string returnString = entrances[0].ToString();
            for (int i = 1; i < entrances.Length; i++)
            {
                returnString = string.Concat(returnString, "\r\n", entrances[i]);
            }
            return returnString;
        }

        public override CaveInfo AddInfo(string newInfo, bool inaccessible)
        {
            if (!inaccessible)
            {
                if (entrances.Length >= 5)
                {
                    MessageBox.Show("A maximum of 5 entrances are supported!");
                    return this;
                }
                else
                {
                    //create backup of data
                    float[] entrancesBackup = entrances;
                    //create new array, length 1 longer
                    entrances = new float[entrances.Length + 1];
                    //copy back in the old data
                    entrancesBackup.CopyTo(entrances, 0);
                    //add the new info
                    try
                    {
                        //corrected to float.Parse
                        entrances[entrances.Length - 1] = float.Parse(newInfo);
                        return this;
                    }
                    catch
                    {
                        MessageBox.Show("invalid number entry!");
                        //uses the backup if added info was invalid
                        entrances = entrancesBackup;
                        return this;
                    }
                }
            } else
            {
                //convert to inaccessible
                //get the info
                string[] info = GetCave();
                //create the instance
                CaveInfoInaccessable updatedCave = new CaveInfoInaccessable();
                //fill the info
                updatedCave.SetCave(info[0], info[1], info[2], "", "0", info[4]);
                //no info is added when converted to inaccessible, skip this step
                return updatedCave;
            }
        }
    }
    public class CaveInfoInaccessable : CaveInfo
    {
        public override string GetEntrance()
        {
            return "Inaccessable";
        }

        public override CaveInfo AddInfo(string newInfo, bool inaccessible)
        {
            MessageBox.Show("Inaccessable Caves can not be modified! please make a new cave instance.");
            return this;
        }
    }
}