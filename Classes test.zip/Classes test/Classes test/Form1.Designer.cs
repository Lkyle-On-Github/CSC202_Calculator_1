﻿namespace Classes_test
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Label entryDescLabel;
            Label viewDescLabel;
            submitButton = new Button();
            locationBox = new TextBox();
            entranceBox = new TextBox();
            deepestBox = new TextBox();
            statusBox = new TextBox();
            nameBox = new TextBox();
            nameLabel = new Label();
            statusLabel = new Label();
            coordinateBox = new TextBox();
            locationLabel = new Label();
            coordinatesLabel = new Label();
            entranceDepthLabel = new Label();
            deepestDepthLabel = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            viewDeepestLabel = new Label();
            viewEntranceLabel = new Label();
            viewLocationLabel = new Label();
            viewStatusLabel = new Label();
            viewNameLabel = new Label();
            leftButton = new Button();
            rightButton = new Button();
            viewingLabel = new Label();
            entryDescLabel = new Label();
            viewDescLabel = new Label();
            SuspendLayout();
            // 
            // entryDescLabel
            // 
            entryDescLabel.AutoSize = true;
            entryDescLabel.Location = new Point(325, 220);
            entryDescLabel.Name = "entryDescLabel";
            entryDescLabel.Size = new Size(119, 20);
            entryDescLabel.TabIndex = 26;
            entryDescLabel.Text = "Enter New Caves";
            // 
            // viewDescLabel
            // 
            viewDescLabel.AutoSize = true;
            viewDescLabel.Location = new Point(303, 37);
            viewDescLabel.Name = "viewDescLabel";
            viewDescLabel.Size = new Size(173, 20);
            viewDescLabel.TabIndex = 27;
            viewDescLabel.Text = "View Documented Caves";
            // 
            // submitButton
            // 
            submitButton.Location = new Point(338, 371);
            submitButton.Name = "submitButton";
            submitButton.Size = new Size(94, 29);
            submitButton.TabIndex = 0;
            submitButton.Text = "Submit";
            submitButton.UseVisualStyleBackColor = true;
            submitButton.Click += button1_Click;
            // 
            // locationBox
            // 
            locationBox.Location = new Point(322, 279);
            locationBox.Name = "locationBox";
            locationBox.Size = new Size(125, 27);
            locationBox.TabIndex = 1;
            // 
            // entranceBox
            // 
            entranceBox.Location = new Point(453, 279);
            entranceBox.Name = "entranceBox";
            entranceBox.Size = new Size(125, 27);
            entranceBox.TabIndex = 2;
            // 
            // deepestBox
            // 
            deepestBox.Location = new Point(584, 279);
            deepestBox.Name = "deepestBox";
            deepestBox.Size = new Size(125, 27);
            deepestBox.TabIndex = 3;
            // 
            // statusBox
            // 
            statusBox.Location = new Point(191, 279);
            statusBox.Name = "statusBox";
            statusBox.Size = new Size(125, 27);
            statusBox.TabIndex = 4;
            // 
            // nameBox
            // 
            nameBox.Location = new Point(60, 279);
            nameBox.Name = "nameBox";
            nameBox.Size = new Size(125, 27);
            nameBox.TabIndex = 5;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new Point(94, 256);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(49, 20);
            nameLabel.TabIndex = 6;
            nameLabel.Text = "Name";
            // 
            // statusLabel
            // 
            statusLabel.AutoSize = true;
            statusLabel.Location = new Point(223, 256);
            statusLabel.Name = "statusLabel";
            statusLabel.Size = new Size(49, 20);
            statusLabel.TabIndex = 7;
            statusLabel.Text = "Status";
            // 
            // coordinateBox
            // 
            coordinateBox.Location = new Point(322, 324);
            coordinateBox.Name = "coordinateBox";
            coordinateBox.Size = new Size(125, 27);
            coordinateBox.TabIndex = 8;
            // 
            // locationLabel
            // 
            locationLabel.AutoSize = true;
            locationLabel.Location = new Point(355, 256);
            locationLabel.Name = "locationLabel";
            locationLabel.Size = new Size(66, 20);
            locationLabel.TabIndex = 9;
            locationLabel.Text = "Location";
            // 
            // coordinatesLabel
            // 
            coordinatesLabel.AutoSize = true;
            coordinatesLabel.Location = new Point(343, 307);
            coordinatesLabel.Name = "coordinatesLabel";
            coordinatesLabel.Size = new Size(89, 20);
            coordinatesLabel.TabIndex = 10;
            coordinatesLabel.Text = "Coordinates";
            // 
            // entranceDepthLabel
            // 
            entranceDepthLabel.AutoSize = true;
            entranceDepthLabel.Location = new Point(460, 257);
            entranceDepthLabel.Name = "entranceDepthLabel";
            entranceDepthLabel.Size = new Size(111, 20);
            entranceDepthLabel.TabIndex = 11;
            entranceDepthLabel.Text = "Entrance Depth";
            entranceDepthLabel.TextAlign = ContentAlignment.TopCenter;
            // 
            // deepestDepthLabel
            // 
            deepestDepthLabel.AutoSize = true;
            deepestDepthLabel.Location = new Point(592, 256);
            deepestDepthLabel.Name = "deepestDepthLabel";
            deepestDepthLabel.Size = new Size(109, 20);
            deepestDepthLabel.TabIndex = 12;
            deepestDepthLabel.Text = "Deepest Depth";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(591, 109);
            label1.Name = "label1";
            label1.Size = new Size(109, 20);
            label1.TabIndex = 17;
            label1.Text = "Deepest Depth";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(459, 110);
            label2.Name = "label2";
            label2.Size = new Size(111, 20);
            label2.TabIndex = 16;
            label2.Text = "Entrance Depth";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(354, 109);
            label3.Name = "label3";
            label3.Size = new Size(66, 20);
            label3.TabIndex = 15;
            label3.Text = "Location";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(222, 109);
            label4.Name = "label4";
            label4.Size = new Size(49, 20);
            label4.TabIndex = 14;
            label4.Text = "Status";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(93, 109);
            label5.Name = "label5";
            label5.Size = new Size(49, 20);
            label5.TabIndex = 13;
            label5.Text = "Name";
            // 
            // viewDeepestLabel
            // 
            viewDeepestLabel.AutoSize = true;
            viewDeepestLabel.Location = new Point(592, 138);
            viewDeepestLabel.MinimumSize = new Size(100, 0);
            viewDeepestLabel.Name = "viewDeepestLabel";
            viewDeepestLabel.Size = new Size(100, 20);
            viewDeepestLabel.TabIndex = 22;
            viewDeepestLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // viewEntranceLabel
            // 
            viewEntranceLabel.AutoSize = true;
            viewEntranceLabel.Location = new Point(460, 139);
            viewEntranceLabel.MinimumSize = new Size(100, 0);
            viewEntranceLabel.Name = "viewEntranceLabel";
            viewEntranceLabel.Size = new Size(100, 20);
            viewEntranceLabel.TabIndex = 21;
            viewEntranceLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // viewLocationLabel
            // 
            viewLocationLabel.AutoSize = true;
            viewLocationLabel.Location = new Point(338, 138);
            viewLocationLabel.MinimumSize = new Size(100, 0);
            viewLocationLabel.Name = "viewLocationLabel";
            viewLocationLabel.Size = new Size(100, 20);
            viewLocationLabel.TabIndex = 20;
            viewLocationLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // viewStatusLabel
            // 
            viewStatusLabel.AutoSize = true;
            viewStatusLabel.ImageAlign = ContentAlignment.MiddleRight;
            viewStatusLabel.Location = new Point(198, 138);
            viewStatusLabel.MinimumSize = new Size(100, 0);
            viewStatusLabel.Name = "viewStatusLabel";
            viewStatusLabel.Size = new Size(100, 20);
            viewStatusLabel.TabIndex = 19;
            viewStatusLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // viewNameLabel
            // 
            viewNameLabel.AutoSize = true;
            viewNameLabel.Location = new Point(70, 138);
            viewNameLabel.MinimumSize = new Size(100, 0);
            viewNameLabel.Name = "viewNameLabel";
            viewNameLabel.Size = new Size(100, 20);
            viewNameLabel.TabIndex = 18;
            viewNameLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // leftButton
            // 
            leftButton.Location = new Point(333, 60);
            leftButton.Name = "leftButton";
            leftButton.Size = new Size(27, 29);
            leftButton.TabIndex = 23;
            leftButton.Text = "<";
            leftButton.UseVisualStyleBackColor = true;
            leftButton.Click += leftButton_Click;
            // 
            // rightButton
            // 
            rightButton.Location = new Point(426, 60);
            rightButton.Name = "rightButton";
            rightButton.Size = new Size(27, 29);
            rightButton.TabIndex = 24;
            rightButton.Text = ">";
            rightButton.UseVisualStyleBackColor = true;
            rightButton.Click += rightButton_Click;
            // 
            // viewingLabel
            // 
            viewingLabel.Anchor = AnchorStyles.None;
            viewingLabel.AutoSize = true;
            viewingLabel.Location = new Point(361, 64);
            viewingLabel.MaximumSize = new Size(60, 0);
            viewingLabel.MinimumSize = new Size(60, 0);
            viewingLabel.Name = "viewingLabel";
            viewingLabel.Size = new Size(60, 20);
            viewingLabel.TabIndex = 25;
            viewingLabel.Text = "x/y";
            viewingLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(viewDescLabel);
            Controls.Add(entryDescLabel);
            Controls.Add(viewingLabel);
            Controls.Add(rightButton);
            Controls.Add(leftButton);
            Controls.Add(viewDeepestLabel);
            Controls.Add(viewEntranceLabel);
            Controls.Add(viewLocationLabel);
            Controls.Add(viewStatusLabel);
            Controls.Add(viewNameLabel);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(deepestDepthLabel);
            Controls.Add(entranceDepthLabel);
            Controls.Add(coordinatesLabel);
            Controls.Add(locationLabel);
            Controls.Add(coordinateBox);
            Controls.Add(statusLabel);
            Controls.Add(nameLabel);
            Controls.Add(nameBox);
            Controls.Add(statusBox);
            Controls.Add(deepestBox);
            Controls.Add(entranceBox);
            Controls.Add(locationBox);
            Controls.Add(submitButton);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button submitButton;
        private TextBox locationBox;
        private TextBox entranceBox;
        private TextBox deepestBox;
        private TextBox statusBox;
        private TextBox nameBox;
        private Label nameLabel;
        private Label statusLabel;
        private TextBox coordinateBox;
        private Label locationLabel;
        private Label coordinatesLabel;
        private Label entranceDepthLabel;
        private Label deepestDepthLabel;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label viewDeepestLabel;
        private Label viewEntranceLabel;
        private Label viewLocationLabel;
        private Label viewStatusLabel;
        private Label viewNameLabel;
        private Button leftButton;
        private Button rightButton;
        private Label viewingLabel;
    }
}
