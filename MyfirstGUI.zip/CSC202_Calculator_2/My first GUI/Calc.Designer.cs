﻿namespace My_first_GUI
{
    partial class GUIForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GUIForm));
            One = new Button();
            two = new Button();
            three = new Button();
            four = new Button();
            five = new Button();
            six = new Button();
            seven = new Button();
            eight = new Button();
            nine = new Button();
            divide = new Button();
            multiply = new Button();
            subtract = new Button();
            add = new Button();
            equals = new Button();
            decimal_point = new Button();
            zero = new Button();
            numOneBox = new TextBox();
            numTwoBox = new TextBox();
            operatorBox = new TextBox();
            gUIFormBindingSource = new BindingSource(components);
            enumMemberAttributeBindingSource = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)gUIFormBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)enumMemberAttributeBindingSource).BeginInit();
            SuspendLayout();
            // 
            // One
            // 
            One.BackColor = Color.Aqua;
            One.BackgroundImage = (Image)resources.GetObject("One.BackgroundImage");
            One.BackgroundImageLayout = ImageLayout.Center;
            One.Font = new Font("Zpix", 10F);
            One.ForeColor = Color.FromArgb(77, 33, 203);
            One.Location = new Point(32, 27);
            One.Name = "One";
            One.Size = new Size(30, 30);
            One.TabIndex = 0;
            One.Text = "1";
            One.UseVisualStyleBackColor = false;
            One.Click += Num_Click;
            // 
            // two
            // 
            two.BackColor = Color.Aqua;
            two.BackgroundImage = (Image)resources.GetObject("two.BackgroundImage");
            two.BackgroundImageLayout = ImageLayout.Center;
            two.Font = new Font("Zpix", 10F);
            two.ForeColor = Color.FromArgb(77, 33, 203);
            two.Location = new Point(73, 27);
            two.Name = "two";
            two.Size = new Size(30, 30);
            two.TabIndex = 1;
            two.Text = "2";
            two.UseVisualStyleBackColor = false;
            two.Click += Num_Click;
            // 
            // three
            // 
            three.BackColor = Color.Aqua;
            three.BackgroundImage = (Image)resources.GetObject("three.BackgroundImage");
            three.BackgroundImageLayout = ImageLayout.Center;
            three.Font = new Font("Zpix", 10F);
            three.ForeColor = Color.FromArgb(77, 33, 203);
            three.Location = new Point(114, 27);
            three.Name = "three";
            three.Size = new Size(30, 30);
            three.TabIndex = 2;
            three.Text = "3";
            three.UseVisualStyleBackColor = false;
            three.Click += Num_Click;
            // 
            // four
            // 
            four.BackColor = Color.Aqua;
            four.BackgroundImage = (Image)resources.GetObject("four.BackgroundImage");
            four.BackgroundImageLayout = ImageLayout.Center;
            four.Font = new Font("Zpix", 10F);
            four.ForeColor = Color.FromArgb(77, 33, 203);
            four.Location = new Point(32, 68);
            four.Name = "four";
            four.Size = new Size(30, 30);
            four.TabIndex = 3;
            four.Text = "4";
            four.UseVisualStyleBackColor = false;
            four.Click += Num_Click;
            // 
            // five
            // 
            five.BackColor = Color.Aqua;
            five.BackgroundImage = (Image)resources.GetObject("five.BackgroundImage");
            five.BackgroundImageLayout = ImageLayout.Center;
            five.Font = new Font("Zpix", 10F);
            five.ForeColor = Color.FromArgb(77, 33, 203);
            five.Location = new Point(73, 68);
            five.Name = "five";
            five.Size = new Size(30, 30);
            five.TabIndex = 4;
            five.Text = "5";
            five.UseVisualStyleBackColor = false;
            five.Click += Num_Click;
            // 
            // six
            // 
            six.BackColor = Color.Aqua;
            six.BackgroundImage = (Image)resources.GetObject("six.BackgroundImage");
            six.BackgroundImageLayout = ImageLayout.Center;
            six.Font = new Font("Zpix", 10F);
            six.ForeColor = Color.FromArgb(77, 33, 203);
            six.Location = new Point(114, 68);
            six.Name = "six";
            six.RightToLeft = RightToLeft.No;
            six.Size = new Size(30, 30);
            six.TabIndex = 5;
            six.Text = "6";
            six.UseVisualStyleBackColor = false;
            six.Click += Num_Click;
            // 
            // seven
            // 
            seven.BackColor = Color.Aqua;
            seven.BackgroundImage = (Image)resources.GetObject("seven.BackgroundImage");
            seven.BackgroundImageLayout = ImageLayout.Center;
            seven.Font = new Font("Zpix", 10F);
            seven.ForeColor = Color.FromArgb(77, 33, 203);
            seven.Location = new Point(32, 109);
            seven.Name = "seven";
            seven.Size = new Size(30, 30);
            seven.TabIndex = 6;
            seven.Text = "7";
            seven.UseVisualStyleBackColor = false;
            seven.Click += Num_Click;
            // 
            // eight
            // 
            eight.BackColor = Color.Aqua;
            eight.BackgroundImage = (Image)resources.GetObject("eight.BackgroundImage");
            eight.BackgroundImageLayout = ImageLayout.Center;
            eight.Font = new Font("Zpix", 10F);
            eight.ForeColor = Color.FromArgb(77, 33, 203);
            eight.Location = new Point(73, 109);
            eight.Name = "eight";
            eight.Size = new Size(30, 30);
            eight.TabIndex = 7;
            eight.Text = "8";
            eight.UseVisualStyleBackColor = false;
            eight.Click += Num_Click;
            // 
            // nine
            // 
            nine.BackColor = Color.Aqua;
            nine.BackgroundImage = (Image)resources.GetObject("nine.BackgroundImage");
            nine.BackgroundImageLayout = ImageLayout.Center;
            nine.Font = new Font("Zpix", 10F);
            nine.ForeColor = Color.FromArgb(77, 33, 203);
            nine.Location = new Point(114, 109);
            nine.Name = "nine";
            nine.Size = new Size(30, 30);
            nine.TabIndex = 8;
            nine.Text = "9";
            nine.UseVisualStyleBackColor = false;
            nine.Click += Num_Click;
            // 
            // divide
            // 
            divide.BackColor = Color.Aqua;
            divide.BackgroundImage = (Image)resources.GetObject("divide.BackgroundImage");
            divide.BackgroundImageLayout = ImageLayout.Center;
            divide.Font = new Font("Zpix", 10F);
            divide.ForeColor = Color.FromArgb(77, 33, 203);
            divide.Location = new Point(155, 27);
            divide.Name = "divide";
            divide.Size = new Size(30, 30);
            divide.TabIndex = 9;
            divide.Tag = "";
            divide.Text = "/";
            divide.UseVisualStyleBackColor = false;
            divide.Click += Divide_Click;
            // 
            // multiply
            // 
            multiply.BackColor = Color.Aqua;
            multiply.BackgroundImage = (Image)resources.GetObject("multiply.BackgroundImage");
            multiply.BackgroundImageLayout = ImageLayout.Center;
            multiply.Font = new Font("Zpix", 10F);
            multiply.ForeColor = Color.FromArgb(77, 33, 203);
            multiply.Location = new Point(155, 68);
            multiply.Name = "multiply";
            multiply.Size = new Size(30, 30);
            multiply.TabIndex = 10;
            multiply.Text = "*";
            multiply.UseVisualStyleBackColor = false;
            multiply.Click += Multiply_Click;
            // 
            // subtract
            // 
            subtract.BackColor = Color.Aqua;
            subtract.BackgroundImage = (Image)resources.GetObject("subtract.BackgroundImage");
            subtract.BackgroundImageLayout = ImageLayout.Center;
            subtract.Font = new Font("Zpix", 10F);
            subtract.ForeColor = Color.FromArgb(77, 33, 203);
            subtract.Location = new Point(155, 109);
            subtract.Name = "subtract";
            subtract.Size = new Size(30, 30);
            subtract.TabIndex = 11;
            subtract.Text = "-";
            subtract.UseVisualStyleBackColor = false;
            subtract.Click += Subtract_Click;
            // 
            // add
            // 
            add.BackColor = Color.Aqua;
            add.BackgroundImage = (Image)resources.GetObject("add.BackgroundImage");
            add.BackgroundImageLayout = ImageLayout.Center;
            add.Font = new Font("Zpix", 10F);
            add.ForeColor = Color.FromArgb(77, 33, 203);
            add.Location = new Point(155, 150);
            add.Name = "add";
            add.Size = new Size(30, 30);
            add.TabIndex = 12;
            add.Text = "+";
            add.UseVisualStyleBackColor = false;
            add.Click += Add_Click;
            // 
            // equals
            // 
            equals.BackColor = Color.Aqua;
            equals.BackgroundImage = (Image)resources.GetObject("equals.BackgroundImage");
            equals.BackgroundImageLayout = ImageLayout.Center;
            equals.Font = new Font("Zpix", 10F);
            equals.ForeColor = Color.FromArgb(77, 33, 203);
            equals.Location = new Point(114, 150);
            equals.Name = "equals";
            equals.Size = new Size(30, 30);
            equals.TabIndex = 13;
            equals.Text = "=";
            equals.UseVisualStyleBackColor = false;
            equals.Click += equals_Click;
            // 
            // decimal_point
            // 
            decimal_point.BackColor = Color.Aqua;
            decimal_point.BackgroundImage = (Image)resources.GetObject("decimal_point.BackgroundImage");
            decimal_point.BackgroundImageLayout = ImageLayout.Center;
            decimal_point.Font = new Font("Zpix", 10F);
            decimal_point.ForeColor = Color.FromArgb(77, 33, 203);
            decimal_point.Location = new Point(73, 150);
            decimal_point.Name = "decimal_point";
            decimal_point.Size = new Size(30, 30);
            decimal_point.TabIndex = 14;
            decimal_point.Text = ".";
            decimal_point.UseVisualStyleBackColor = false;
            decimal_point.Click += Num_Click;
            // 
            // zero
            // 
            zero.BackColor = Color.Aqua;
            zero.BackgroundImage = (Image)resources.GetObject("zero.BackgroundImage");
            zero.BackgroundImageLayout = ImageLayout.Center;
            zero.Font = new Font("Zpix", 10F);
            zero.ForeColor = Color.FromArgb(77, 33, 203);
            zero.Location = new Point(32, 150);
            zero.Name = "zero";
            zero.Size = new Size(30, 30);
            zero.TabIndex = 15;
            zero.Text = "0";
            zero.UseVisualStyleBackColor = false;
            zero.Click += Num_Click;
            // 
            // numOneBox
            // 
            numOneBox.BackColor = Color.FromArgb(243, 243, 242);
            numOneBox.BorderStyle = BorderStyle.None;
            numOneBox.Font = new Font("Zpix", 9F, FontStyle.Regular, GraphicsUnit.Point, 128);
            numOneBox.ForeColor = Color.FromArgb(49, 49, 49);
            numOneBox.Location = new Point(23, 6);
            numOneBox.MaxLength = 8;
            numOneBox.Name = "numOneBox";
            numOneBox.Size = new Size(80, 15);
            numOneBox.TabIndex = 16;
            numOneBox.Enter += numOneBox_Enter;
            // 
            // numTwoBox
            // 
            numTwoBox.BackColor = Color.FromArgb(243, 243, 242);
            numTwoBox.BorderStyle = BorderStyle.None;
            numTwoBox.Font = new Font("Zpix", 9F, FontStyle.Regular, GraphicsUnit.Point, 128);
            numTwoBox.ForeColor = Color.FromArgb(49, 49, 49);
            numTwoBox.Location = new Point(120, 6);
            numTwoBox.MaxLength = 8;
            numTwoBox.Name = "numTwoBox";
            numTwoBox.Size = new Size(80, 15);
            numTwoBox.TabIndex = 17;
            numTwoBox.Enter += numTwoBox_Enter;
            // 
            // operatorBox
            // 
            operatorBox.BackColor = Color.FromArgb(255, 248, 255);
            operatorBox.BorderStyle = BorderStyle.None;
            operatorBox.Enabled = false;
            operatorBox.Font = new Font("Zpix", 9F, FontStyle.Regular, GraphicsUnit.Point, 128);
            operatorBox.ForeColor = Color.FromArgb(80, 32, 207);
            operatorBox.Location = new Point(104, 6);
            operatorBox.Name = "operatorBox";
            operatorBox.Size = new Size(10, 15);
            operatorBox.TabIndex = 19;
            operatorBox.TabStop = false;
            operatorBox.TextAlign = HorizontalAlignment.Center;
            // 
            // gUIFormBindingSource
            // 
            gUIFormBindingSource.DataSource = typeof(GUIForm);
            // 
            // enumMemberAttributeBindingSource
            // 
            enumMemberAttributeBindingSource.DataSource = typeof(System.Runtime.Serialization.EnumMemberAttribute);
            // 
            // GUIForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 248, 255);
            ClientSize = new Size(226, 193);
            Controls.Add(operatorBox);
            Controls.Add(numTwoBox);
            Controls.Add(numOneBox);
            Controls.Add(zero);
            Controls.Add(decimal_point);
            Controls.Add(equals);
            Controls.Add(add);
            Controls.Add(subtract);
            Controls.Add(multiply);
            Controls.Add(divide);
            Controls.Add(nine);
            Controls.Add(eight);
            Controls.Add(seven);
            Controls.Add(six);
            Controls.Add(five);
            Controls.Add(four);
            Controls.Add(three);
            Controls.Add(two);
            Controls.Add(One);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "GUIForm";
            Text = "Calc";
            ((System.ComponentModel.ISupportInitialize)gUIFormBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)enumMemberAttributeBindingSource).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }


        #endregion

        private Button One;
        private Button two;
        private Button three;
        private Button four;
        private Button five;
        private Button six;
        private Button seven;
        private Button eight;
        private Button nine;
        private Button divide;
        private Button multiply;
        private Button subtract;
        private Button add;
        private Button equals;
        private Button decimal_point;
        private Button zero;
        private TextBox numOneBox;
        private TextBox numTwoBox;
        private TextBox operatorBox;
        private BindingSource enumMemberAttributeBindingSource;
        private BindingSource gUIFormBindingSource;
    }
}
