namespace My_first_GUI
{
    public partial class GUIForm : Form
    {
        //enum for operations, which is used in the equals switch
        //statement to know what operation is being performed.
        private enum Operations {Unselected, Divide, Multiply, Subtract, Add }
        private Operations operation = Operations.Unselected;
        //variables for the numbers.
        public double numOne = 0;
        public double numTwo = 0;
        public double result = 0;

        //variable to store which box is currently selected, defaults to the first box
        private TextBox currBox = new TextBox();
        private String errorMessage = string.Empty;


        public GUIForm()
        {
            InitializeComponent();
            //I need it to default to entering in the first box, thankfully this seems to work
            currBox = numOneBox;
        }

        private void Num_Click(object sender, EventArgs e)
        {
            /*
                While originally I had a seperate function for each button, while I was 
                setting it up I noticed how to change the function each button was bound
                to and that the automatic function it generates has an arguement called
                sender, so after a little experimenting I was able to get it working
                with only one function.
            */
            //checks the length of the text in the box with
            //the MaxLength value set in the designer.
            if (currBox.Text.Length < currBox.MaxLength)
            {
                //casts the sender to a button so that I can get the text
                Button pressed = sender as Button;
                //add the number displayed on the button to the end of the string.
                currBox.Text += pressed.Text;
                /*
                    While it might seem like I am turning a number into a string with
                    the intention of turning it back into a number, what we are trying to
                    do is add a digit on to the end of a number, which isn't really
                    something that makes sense as a mathematical operation. Really we are
                    treating these numbers like they are strings until it is time to do 
                    math on them, so I think handling the data like this makes more sense.
                */
            }

        }


        //Operation functions:
        /*
            Update the text box in the middle to display the current operation.
            Then, update the operation for use when equals is pressed.
            Also, set the currently selected box for the keypad to the second box
            this should make it feel more like using a normal calculator.
        */
        //I determined it would be more efficient to have a different function for each operator here,
        //since the operation buttons dont have any intrinsic link to the operation enum, I would
        //have to do some sort of switch statement that would end up being just as long.
        private void Divide_Click(object sender, EventArgs e)
        {
            operatorBox.Text = "/";
            operation = Operations.Divide;
            currBox = numTwoBox;
        }
        private void Multiply_Click(object sender, EventArgs e)
        {
            operatorBox.Text = "*";
            operation = Operations.Multiply;
            currBox = numTwoBox;
        }
        private void Subtract_Click(object sender, EventArgs e)
        {
            operatorBox.Text = "-";
            operation = Operations.Subtract;
            currBox = numTwoBox;
        }
        private void Add_Click(object sender, EventArgs e)
        {
            operatorBox.Text = "+";
            operation = Operations.Add;
            currBox = numTwoBox;
        }

        //when the player clicks on an entry box, it
        //changes the box that the keypad enters numbers into.
        private void numOneBox_Enter(object sender, EventArgs e)
        {
            currBox = numOneBox;
        }

        private void numTwoBox_Enter(object sender, EventArgs e)
        {
            currBox = numTwoBox;
        }

        private void equals_Click(object sender, EventArgs e)
        {
            //reset the errorMessage string to default value
            errorMessage = string.Empty;
            //since it's time to do math, the number will be temporarily converted to a string
            //attempt to read the string as a double, outputing the result to numOne
            if(!Double.TryParse(numOneBox.Text, out numOne))
            {
                //if it could not parse (due to invalid use of the . button), add that to the error message)
                errorMessage += "Invalid entry for first number! ";
            }
            //same as numOne
            if(!Double.TryParse(numTwoBox.Text, out numTwo))
            {
                errorMessage += "Invalid entry for second number!! ";
            }
            if(operation == Operations.Unselected)
            {
                //if no operation was selected, give error !! !!!
                errorMessage += "No operation was selected!!!";
            }

            //if any error message is to be displayed, dont display the result.
            if (errorMessage == string.Empty)
            {
                switch (operation)
                {
                    case Operations.Divide:
                        //catch for division by zero
                        if (numTwo == 0)
                        {
                            MessageBox.Show("You can't divide by 0, Silly!!!!");
                        }
                        //else statement so that it doesnt divide by zero
                        else
                        {
                            result = numOne / numTwo;
                            MessageBox.Show("The answer is: " + result.ToString());
                        }
                        break;

                    case Operations.Multiply:
                        //just using C# multiplication
                        result = numOne * numTwo;
                        MessageBox.Show("The answer is: " + result.ToString());
                        break;

                    case Operations.Subtract:
                        //just using C# subtraction
                        result = numOne - numTwo;
                        MessageBox.Show("The answer is: " + result.ToString());
                        break;

                    case Operations.Add:
                        //just using C# addition
                        result = numOne + numTwo;
                        MessageBox.Show("The answer is: " + result.ToString());
                        break;
                    
                }
            } else
            {
                //if there was an error, show the compiled error message.
                MessageBox.Show(errorMessage);
            }
            
        }
    }
}
