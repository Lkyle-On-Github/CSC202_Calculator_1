namespace My_first_GUI
{
    public partial class GUIForm : Form
    {
        public GUIForm()
        {
            InitializeComponent();
        }

        private void PushMe_Click(object sender, EventArgs e)
        {
            MessageBox.Show("You pushed me!");
        }
    }
}
