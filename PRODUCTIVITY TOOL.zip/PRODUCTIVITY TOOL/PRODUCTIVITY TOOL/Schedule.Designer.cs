﻿namespace PRODUCTIVITY_TOOL
{
    //using System.DateTime;
    partial class Schedule
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Schedule));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.addProject = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.projectNameBox = new System.Windows.Forms.TextBox();
            this.projectDateLabel = new System.Windows.Forms.Label();
            this.projectNameLabel = new System.Windows.Forms.Label();
            this.project0Name = new System.Windows.Forms.Label();
            this.project1Name = new System.Windows.Forms.Label();
            this.project2Name = new System.Windows.Forms.Label();
            this.project3Name = new System.Windows.Forms.Label();
            this.project4Name = new System.Windows.Forms.Label();
            this.project5Name = new System.Windows.Forms.Label();
            this.project6Name = new System.Windows.Forms.Label();
            this.project7Name = new System.Windows.Forms.Label();
            this.project0Date = new System.Windows.Forms.Label();
            this.project1Date = new System.Windows.Forms.Label();
            this.project2Date = new System.Windows.Forms.Label();
            this.project3Date = new System.Windows.Forms.Label();
            this.project4Date = new System.Windows.Forms.Label();
            this.project5Date = new System.Windows.Forms.Label();
            this.project6Date = new System.Windows.Forms.Label();
            this.project7Date = new System.Windows.Forms.Label();
            this.Delete0 = new System.Windows.Forms.Button();
            this.Delete1 = new System.Windows.Forms.Button();
            this.Delete2 = new System.Windows.Forms.Button();
            this.Delete3 = new System.Windows.Forms.Button();
            this.Delete4 = new System.Windows.Forms.Button();
            this.Delete5 = new System.Windows.Forms.Button();
            this.Delete6 = new System.Windows.Forms.Button();
            this.Delete7 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1093, 173);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // addProject
            // 
            this.addProject.Location = new System.Drawing.Point(468, 283);
            this.addProject.Name = "addProject";
            this.addProject.Size = new System.Drawing.Size(112, 35);
            this.addProject.TabIndex = 1;
            this.addProject.Text = "Add Project";
            this.addProject.UseVisualStyleBackColor = true;
            this.addProject.Click += new System.EventHandler(this.addProject_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(528, 234);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(249, 22);
            this.dateTimePicker1.TabIndex = 2;
            // 
            // projectNameBox
            // 
            this.projectNameBox.Location = new System.Drawing.Point(316, 236);
            this.projectNameBox.Name = "projectNameBox";
            this.projectNameBox.Size = new System.Drawing.Size(167, 22);
            this.projectNameBox.TabIndex = 3;
            this.projectNameBox.Enter += new System.EventHandler(this.projectNameBox_Enter);
            this.projectNameBox.Leave += new System.EventHandler(this.projectNameBox_Leave);
            // 
            // projectDateLabel
            // 
            this.projectDateLabel.AutoSize = true;
            this.projectDateLabel.Location = new System.Drawing.Point(611, 262);
            this.projectDateLabel.Name = "projectDateLabel";
            this.projectDateLabel.Size = new System.Drawing.Size(81, 16);
            this.projectDateLabel.TabIndex = 5;
            this.projectDateLabel.Text = "Project Date";
            // 
            // projectNameLabel
            // 
            this.projectNameLabel.AutoSize = true;
            this.projectNameLabel.Location = new System.Drawing.Point(355, 262);
            this.projectNameLabel.Name = "projectNameLabel";
            this.projectNameLabel.Size = new System.Drawing.Size(89, 16);
            this.projectNameLabel.TabIndex = 4;
            this.projectNameLabel.Text = "Project Name";
            // 
            // project0Name
            // 
            this.project0Name.AutoSize = true;
            this.project0Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project0Name.Location = new System.Drawing.Point(7, 99);
            this.project0Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project0Name.Name = "project0Name";
            this.project0Name.Size = new System.Drawing.Size(100, 16);
            this.project0Name.TabIndex = 6;
            this.project0Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project1Name
            // 
            this.project1Name.AutoSize = true;
            this.project1Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project1Name.Location = new System.Drawing.Point(147, 99);
            this.project1Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project1Name.Name = "project1Name";
            this.project1Name.Size = new System.Drawing.Size(100, 16);
            this.project1Name.TabIndex = 7;
            this.project1Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project2Name
            // 
            this.project2Name.AutoSize = true;
            this.project2Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project2Name.Location = new System.Drawing.Point(285, 99);
            this.project2Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project2Name.Name = "project2Name";
            this.project2Name.Size = new System.Drawing.Size(100, 16);
            this.project2Name.TabIndex = 8;
            this.project2Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project3Name
            // 
            this.project3Name.AutoSize = true;
            this.project3Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project3Name.Location = new System.Drawing.Point(425, 99);
            this.project3Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project3Name.Name = "project3Name";
            this.project3Name.Size = new System.Drawing.Size(100, 16);
            this.project3Name.TabIndex = 9;
            this.project3Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project4Name
            // 
            this.project4Name.AutoSize = true;
            this.project4Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project4Name.Location = new System.Drawing.Point(549, 99);
            this.project4Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project4Name.Name = "project4Name";
            this.project4Name.Size = new System.Drawing.Size(100, 16);
            this.project4Name.TabIndex = 10;
            this.project4Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project5Name
            // 
            this.project5Name.AutoSize = true;
            this.project5Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project5Name.Location = new System.Drawing.Point(688, 99);
            this.project5Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project5Name.Name = "project5Name";
            this.project5Name.Size = new System.Drawing.Size(100, 16);
            this.project5Name.TabIndex = 11;
            this.project5Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project6Name
            // 
            this.project6Name.AutoSize = true;
            this.project6Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project6Name.Location = new System.Drawing.Point(822, 99);
            this.project6Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project6Name.Name = "project6Name";
            this.project6Name.Size = new System.Drawing.Size(100, 16);
            this.project6Name.TabIndex = 12;
            this.project6Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project7Name
            // 
            this.project7Name.AutoSize = true;
            this.project7Name.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project7Name.Location = new System.Drawing.Point(952, 99);
            this.project7Name.MinimumSize = new System.Drawing.Size(100, 16);
            this.project7Name.Name = "project7Name";
            this.project7Name.Size = new System.Drawing.Size(100, 16);
            this.project7Name.TabIndex = 13;
            this.project7Name.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project0Date
            // 
            this.project0Date.AutoSize = true;
            this.project0Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project0Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project0Date.Location = new System.Drawing.Point(7, 148);
            this.project0Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project0Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project0Date.Name = "project0Date";
            this.project0Date.Size = new System.Drawing.Size(100, 14);
            this.project0Date.TabIndex = 14;
            this.project0Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project1Date
            // 
            this.project1Date.AutoSize = true;
            this.project1Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project1Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project1Date.Location = new System.Drawing.Point(147, 148);
            this.project1Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project1Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project1Date.Name = "project1Date";
            this.project1Date.Size = new System.Drawing.Size(100, 14);
            this.project1Date.TabIndex = 15;
            this.project1Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project2Date
            // 
            this.project2Date.AutoSize = true;
            this.project2Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project2Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project2Date.Location = new System.Drawing.Point(285, 148);
            this.project2Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project2Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project2Date.Name = "project2Date";
            this.project2Date.Size = new System.Drawing.Size(100, 14);
            this.project2Date.TabIndex = 16;
            this.project2Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project3Date
            // 
            this.project3Date.AutoSize = true;
            this.project3Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project3Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project3Date.Location = new System.Drawing.Point(425, 148);
            this.project3Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project3Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project3Date.Name = "project3Date";
            this.project3Date.Size = new System.Drawing.Size(100, 14);
            this.project3Date.TabIndex = 17;
            this.project3Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project4Date
            // 
            this.project4Date.AutoSize = true;
            this.project4Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project4Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project4Date.Location = new System.Drawing.Point(549, 148);
            this.project4Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project4Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project4Date.Name = "project4Date";
            this.project4Date.Size = new System.Drawing.Size(100, 14);
            this.project4Date.TabIndex = 18;
            this.project4Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project5Date
            // 
            this.project5Date.AutoSize = true;
            this.project5Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project5Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project5Date.Location = new System.Drawing.Point(688, 148);
            this.project5Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project5Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project5Date.Name = "project5Date";
            this.project5Date.Size = new System.Drawing.Size(100, 14);
            this.project5Date.TabIndex = 19;
            this.project5Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project6Date
            // 
            this.project6Date.AutoSize = true;
            this.project6Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project6Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project6Date.Location = new System.Drawing.Point(822, 148);
            this.project6Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project6Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project6Date.Name = "project6Date";
            this.project6Date.Size = new System.Drawing.Size(100, 14);
            this.project6Date.TabIndex = 20;
            this.project6Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // project7Date
            // 
            this.project7Date.AutoSize = true;
            this.project7Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project7Date.ForeColor = System.Drawing.SystemColors.ControlText;
            this.project7Date.Location = new System.Drawing.Point(952, 148);
            this.project7Date.MaximumSize = new System.Drawing.Size(100, 16);
            this.project7Date.MinimumSize = new System.Drawing.Size(100, 14);
            this.project7Date.Name = "project7Date";
            this.project7Date.Size = new System.Drawing.Size(100, 14);
            this.project7Date.TabIndex = 21;
            this.project7Date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Delete0
            // 
            this.Delete0.Location = new System.Drawing.Point(22, 179);
            this.Delete0.Name = "Delete0";
            this.Delete0.Size = new System.Drawing.Size(70, 35);
            this.Delete0.TabIndex = 22;
            this.Delete0.Text = "Delete";
            this.Delete0.UseVisualStyleBackColor = true;
            this.Delete0.Click += new System.EventHandler(this.Delete0_Click);
            // 
            // Delete1
            // 
            this.Delete1.Location = new System.Drawing.Point(160, 179);
            this.Delete1.Name = "Delete1";
            this.Delete1.Size = new System.Drawing.Size(70, 35);
            this.Delete1.TabIndex = 23;
            this.Delete1.Text = "Delete";
            this.Delete1.UseVisualStyleBackColor = true;
            this.Delete1.Click += new System.EventHandler(this.Delete1_Click);
            // 
            // Delete2
            // 
            this.Delete2.Location = new System.Drawing.Point(298, 179);
            this.Delete2.Name = "Delete2";
            this.Delete2.Size = new System.Drawing.Size(70, 35);
            this.Delete2.TabIndex = 24;
            this.Delete2.Text = "Delete";
            this.Delete2.UseVisualStyleBackColor = true;
            this.Delete2.Click += new System.EventHandler(this.Delete2_Click);
            // 
            // Delete3
            // 
            this.Delete3.Location = new System.Drawing.Point(438, 179);
            this.Delete3.Name = "Delete3";
            this.Delete3.Size = new System.Drawing.Size(70, 35);
            this.Delete3.TabIndex = 25;
            this.Delete3.Text = "Delete";
            this.Delete3.UseVisualStyleBackColor = true;
            this.Delete3.Click += new System.EventHandler(this.Delete3_Click);
            // 
            // Delete4
            // 
            this.Delete4.Location = new System.Drawing.Point(562, 179);
            this.Delete4.Name = "Delete4";
            this.Delete4.Size = new System.Drawing.Size(70, 35);
            this.Delete4.TabIndex = 26;
            this.Delete4.Text = "Delete";
            this.Delete4.UseVisualStyleBackColor = true;
            this.Delete4.Click += new System.EventHandler(this.Delete4_Click);
            // 
            // Delete5
            // 
            this.Delete5.Location = new System.Drawing.Point(707, 179);
            this.Delete5.Name = "Delete5";
            this.Delete5.Size = new System.Drawing.Size(70, 35);
            this.Delete5.TabIndex = 27;
            this.Delete5.Text = "Delete";
            this.Delete5.UseVisualStyleBackColor = true;
            this.Delete5.Click += new System.EventHandler(this.Delete5_Click);
            // 
            // Delete6
            // 
            this.Delete6.Location = new System.Drawing.Point(837, 179);
            this.Delete6.Name = "Delete6";
            this.Delete6.Size = new System.Drawing.Size(70, 35);
            this.Delete6.TabIndex = 28;
            this.Delete6.Text = "Delete";
            this.Delete6.UseVisualStyleBackColor = true;
            this.Delete6.Click += new System.EventHandler(this.Delete6_Click);
            // 
            // Delete7
            // 
            this.Delete7.Location = new System.Drawing.Point(965, 179);
            this.Delete7.Name = "Delete7";
            this.Delete7.Size = new System.Drawing.Size(70, 35);
            this.Delete7.TabIndex = 22;
            this.Delete7.Text = "Delete";
            this.Delete7.UseVisualStyleBackColor = true;
            this.Delete7.Click += new System.EventHandler(this.Delete7_Click);
            // 
            // Schedule
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1098, 452);
            this.Controls.Add(this.Delete0);
            this.Controls.Add(this.Delete1);
            this.Controls.Add(this.Delete2);
            this.Controls.Add(this.Delete3);
            this.Controls.Add(this.Delete4);
            this.Controls.Add(this.Delete5);
            this.Controls.Add(this.Delete6);
            this.Controls.Add(this.Delete7);
            this.Controls.Add(this.project7Date);
            this.Controls.Add(this.project6Date);
            this.Controls.Add(this.project5Date);
            this.Controls.Add(this.project4Date);
            this.Controls.Add(this.project3Date);
            this.Controls.Add(this.project2Date);
            this.Controls.Add(this.project1Date);
            this.Controls.Add(this.project0Date);
            this.Controls.Add(this.project7Name);
            this.Controls.Add(this.project6Name);
            this.Controls.Add(this.project5Name);
            this.Controls.Add(this.project4Name);
            this.Controls.Add(this.project3Name);
            this.Controls.Add(this.project2Name);
            this.Controls.Add(this.project1Name);
            this.Controls.Add(this.project0Name);
            this.Controls.Add(this.projectDateLabel);
            this.Controls.Add(this.projectNameLabel);
            this.Controls.Add(this.projectNameBox);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.addProject);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Schedule";
            this.Text = "Schedule";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button addProject;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox projectNameBox;
        private System.Windows.Forms.Label projectDateLabel;
        private System.Windows.Forms.Label projectNameLabel;
        private System.Windows.Forms.Label project0Name;
        private System.Windows.Forms.Label project1Name;
        private System.Windows.Forms.Label project2Name;
        private System.Windows.Forms.Label project3Name;
        private System.Windows.Forms.Label project4Name;
        private System.Windows.Forms.Label project5Name;
        private System.Windows.Forms.Label project6Name;
        private System.Windows.Forms.Label project7Name;
        private System.Windows.Forms.Label project0Date;
        private System.Windows.Forms.Label project1Date;
        private System.Windows.Forms.Label project2Date;
        private System.Windows.Forms.Label project3Date;
        private System.Windows.Forms.Label project4Date;
        private System.Windows.Forms.Label project5Date;
        private System.Windows.Forms.Label project6Date;
        private System.Windows.Forms.Label project7Date;
        private System.Windows.Forms.Button Delete0;
        private System.Windows.Forms.Button Delete1;
        private System.Windows.Forms.Button Delete2;
        private System.Windows.Forms.Button Delete3;
        private System.Windows.Forms.Button Delete4;
        private System.Windows.Forms.Button Delete5;
        private System.Windows.Forms.Button Delete6;
        private System.Windows.Forms.Button Delete7;
    }
}

