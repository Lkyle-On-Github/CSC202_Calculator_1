﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace PRODUCTIVITY_TOOL
{
    public partial class Schedule : Form
    {
        string lastString = string.Empty;
        //array with all the buttons
        Label[,] scheduleText = new Label[8,8];
        //arrays to store the linked names and dates
        string[] projNames = new string[0];
        DateTime[] projDates = new DateTime[0];

        //array that stores which column each data entry is tied to, so that deletion works
        int[] linkedButton = new int[8];
        //int deletedIndex = 0;
        public Schedule()
        {
            InitializeComponent();
            placeholderText(false);
            scheduleText = new Label[,] { { project0Name, project1Name, project2Name, project3Name, project4Name, project5Name, project6Name, project7Name }, {project0Date, project1Date, project2Date, project3Date, project4Date, project5Date, project6Date, project7Date} };
        }

        private void projectNameBox_Enter(object sender, EventArgs e)
        {
            // if the default text is being displayed, prepare the box to display normal text.
            // has an additional check to ensure someone is allowed to name their project project name if they wish to do so
            if (lastString != "Project Name" && projectNameBox.Text == "Project Name")
            {
                placeholderText(true);
            }
        }
        private void projectNameBox_Leave(object sender, EventArgs e)
        {
            //get the string that was entered
            lastString = projectNameBox.Text;
            //if it was nothing, put back the placeholder text.
            if (lastString == string.Empty)
            {
                placeholderText(false);
            }
        }

        private void addProject_Click(object sender, EventArgs e)
        {
            //reset the value of linkedButton
            linkedButton = new int[8];

            //if the array isnt full
            if (projDates.Length < 8)
            {

                //add the new data to arrays
                //projDates = projDates.Append(dateTimePicker1.Value) as DateTime[];
                //projNames = projNames.Append(projectNameBox.Text) as string[];

                //add the new data to arrays attempt 2
                Array.Resize(ref projDates, projDates.Length + 1);
                projDates[projDates.Length - 1] = dateTimePicker1.Value.Date;
                Array.Resize(ref projNames, projNames.Length + 1);
                projNames[projNames.Length - 1] = projectNameBox.Text;


                UpdateSchedule();

                
            } else
            {
                MessageBox.Show("Your Schedule Is Full!");
            }
            projectNameBox.Text = string.Empty;

        }

        //Simulates placeholder text cuz I couldn't find the actual thing to do it
        private void placeholderText(bool _removing)
        {

            if (_removing)
            {
                //when removing the text, set the color to black, remove the text, and change the alignment to left
                projectNameBox.ForeColor = Color.Black;
                projectNameBox.Text = "";
                projectNameBox.TextAlign = HorizontalAlignment.Left;
            }
            else
            {
                //when adding back the placeholder text, set the color to grey, add the text project name and align the text to the center
                projectNameBox.ForeColor = Color.Gray;
                projectNameBox.TextAlign = HorizontalAlignment.Center;
                projectNameBox.Text = "Project Name";
            }
        }

        private void Delete0_Click(object sender, EventArgs e)
        {
            Delete(0);
        }

        private void Delete1_Click(object sender, EventArgs e)
        {
            Delete(1);
        }

        private void Delete2_Click(object sender, EventArgs e)
        {
            Delete(2);
        }

        private void Delete3_Click(object sender, EventArgs e)
        {
            Delete(3);
        }

        private void Delete4_Click(object sender, EventArgs e)
        {
            Delete(4);
        }

        private void Delete5_Click(object sender, EventArgs e)
        {
            Delete(5);
        }

        private void Delete6_Click(object sender, EventArgs e)
        {
            Delete(6);
        }

        private void Delete7_Click(object sender, EventArgs e)
        {
            Delete(7);
        }

        private void Delete(int _index)
        {
            //copy data into new arrays and clear the old ones
            DateTime[] datesCopy = projDates;
            string[] namesCopy = projNames;
            projDates = new DateTime[projDates.Length - 1];
            projNames = new string[projNames.Length - 1];
            int _i_out = 0;
            //one at a time, copy the data back into the original arrays, unless that data is the deleted index
            for (int __i = 0; __i < datesCopy.Length; __i++)
            {
                if (__i != _index)
                {
                    projDates[_i_out] = datesCopy[linkedButton[__i]];
                    projNames[_i_out] = namesCopy[linkedButton[__i]];
                    //the index we are outputting to only updates if an array index was filled
                    _i_out += 1;
                }
            }
            //update the schedule
            UpdateSchedule();
        }

        private void UpdateSchedule()
        {
            //iterate through the 2d array, clearing all the text in the labels.
            for (int _i = 0; _i < 8; _i++)
            {
                scheduleText[0, _i].Text = string.Empty;
                scheduleText[1, _i].Text = string.Empty;
            }

            //copy data into new array so that it can be sorted lazily
            DateTime[] projDatesCopy = new DateTime[projDates.Length];
            projDates.CopyTo(projDatesCopy, 0);

            for (int i = 0; i < projDates.Length; i++)
            {
                //put the minimum in the label
                scheduleText[1, i].Text = projDatesCopy.Min().ToString();
                //remove 12:00:00 from the end of the string
                scheduleText[1, i].Text = scheduleText[1, i].Text.Remove(scheduleText[1, i].Text.Length - 12);
                //set the linking number of the schedule slot to the array index of the values in that slot
                linkedButton.SetValue(Array.IndexOf(projDatesCopy, projDatesCopy.Min()), i);
                //use the linking number to set the project name
                scheduleText[0, i].Text = projNames.GetValue(linkedButton[i]).ToString();

                //fill the projDatesCopy value with the maximum possible value so that my lazy sorting works
                projDatesCopy[linkedButton[i]] = DateTime.MaxValue;
                //projDatesCopy.SetValue(DateTime.MaxValue, Array.IndexOf(projDatesCopy, projDatesCopy.Min()));
            }
        }
    }
}
