﻿using System;
//using for streamreader/writer
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System.Diagnostics;

namespace PRODUCTIVITY_TOOL
{
    public partial class Schedule : Form
    {
        //if I ever wanted to change the number of entries possible in the schedule, I would just have to change this rather than updating a few random lines throughout the code.
        //except for the 2 lines right below here I guess because thats illegal >:(
        int maxEntries = 8;
        string lastString = string.Empty;

        //array with all the buttons
        Label[,] scheduleText = new Label[8, 8];
        //arrays to store the linked names and dates
        public string[] projNames = new string[0];
        public DateTime[] projDates = new DateTime[0];

        //gets the current directory the program is running in and prepares the names of the savedata files.
        //savedata is checked for and written to by checking for these file names in the current directory.
        string nameSavePath = string.Concat(Directory.GetCurrentDirectory(), "\\ScheduleNameSave.txt");
        string dateSavePath = string.Concat(Directory.GetCurrentDirectory(), "\\ScheduleDateSave.txt");

        //array that stores which column each data entry is tied to, so that deletion works
        int[] linkedButton = new int[8];
        //int deletedIndex = 0;
        public Schedule()
        {
            InitializeComponent();
            placeholderText(false);
            scheduleText = new Label[,] { { project0Name, project1Name, project2Name, project3Name, project4Name, project5Name, project6Name, project7Name }, {project0Date, project1Date, project2Date, project3Date, project4Date, project5Date, project6Date, project7Date} };
            
            //if the user already has a saved schedule, automatically load it for them.
            if (File.Exists(nameSavePath) && File.Exists(dateSavePath))
            {
                LoadSchedule();
            } else
            {
                InitSaves();
            }
        }

        private void projectNameBox_Enter(object sender, EventArgs e)
        {
            // if the default text is being displayed, prepare the box to display normal text.
            // has an additional check to ensure someone is allowed to name their project project name if they wish to do so
            if (lastString != "Project Name" && projectNameBox.Text == "Project Name")
            {
                placeholderText(true);
            }
        }
        private void projectNameBox_Leave(object sender, EventArgs e)
        {
            //get the string that was entered
            lastString = projectNameBox.Text;
            //if it was nothing, put back the placeholder text.
            if (lastString == string.Empty)
            {
                placeholderText(false);
            }
        }

        private void addProject_Click(object sender, EventArgs e)
        {
            //reset the value of linkedButton
            linkedButton = new int[maxEntries];

            //if the array isnt full
            if (projDates.Length < maxEntries)
            {

                //add the new data to arrays
                //projDates = projDates.Append(dateTimePicker1.Value) as DateTime[];
                //projNames = projNames.Append(projectNameBox.Text) as string[];

                //add the new data to arrays attempt 2
                Array.Resize(ref projDates, projDates.Length + 1);
                projDates[projDates.Length - 1] = dateTimePicker1.Value.Date;
                Array.Resize(ref projNames, projNames.Length + 1);

                if (projectNameBox.Text != "")
                {
                    //if there is text, put it in
                    projNames[projNames.Length - 1] = projectNameBox.Text;
                }
                else
                {
                    //otherwise, default to Project Name
                    projectNameBox.Text = "Project Name";
                }


                    UpdateSchedule();
                //Autosave on schedule update
                //SaveSchedule();


            } else
            {
                MessageBox.Show("Your Schedule Is Full!");
            }
            placeholderText(false);
            
            
        }

        //Simulates placeholder text cuz I couldn't find the actual thing to do it
        private void placeholderText(bool _removing)
        {

            if (_removing)
            {
                //when removing the text, set the color to black, remove the text, and change the alignment to left
                projectNameBox.ForeColor = Color.Black;
                projectNameBox.Text = "";
                projectNameBox.TextAlign = HorizontalAlignment.Left;
            }
            else
            {
                //when adding back the placeholder text, set the color to grey, add the text project name and align the text to the center
                projectNameBox.ForeColor = Color.Gray;
                projectNameBox.TextAlign = HorizontalAlignment.Center;
                projectNameBox.Text = "Project Name";
            }
        }
        #region delete
        private void Delete0_Click(object sender, EventArgs e)
        {
            Delete(0);
        }

        private void Delete1_Click(object sender, EventArgs e)
        {
            Delete(1);
        }

        private void Delete2_Click(object sender, EventArgs e)
        {
            Delete(2);
        }

        private void Delete3_Click(object sender, EventArgs e)
        {
            Delete(3);
        }

        private void Delete4_Click(object sender, EventArgs e)
        {
            Delete(4);
        }

        private void Delete5_Click(object sender, EventArgs e)
        {
            Delete(5);
        }

        private void Delete6_Click(object sender, EventArgs e)
        {
            Delete(6);
        }

        private void Delete7_Click(object sender, EventArgs e)
        {
            Delete(7);
        }

        private void Delete(int _index)
        {
            if (projDates.Length != 0 && projNames.Length != 0)
            {
                //copy data into new arrays and clear the old ones
                DateTime[] datesCopy = projDates;
                string[] namesCopy = projNames;
                projDates = new DateTime[projDates.Length - 1];
                projNames = new string[projNames.Length - 1];
                int _i_out = 0;
                //one at a time, copy the data back into the original arrays, unless that data is the deleted index
                for (int __i = 0; __i < datesCopy.Length; __i++)
                {
                    if (__i != _index)
                    {
                        projDates[_i_out] = datesCopy[linkedButton[__i]];
                        projNames[_i_out] = namesCopy[linkedButton[__i]];
                        //the index we are outputting to only updates if an array index was filled
                        _i_out += 1;
                    }
                }
                //update the schedule
                UpdateSchedule();
            }
        }

        #endregion
        private void UpdateSchedule()
        {
            //iterate through the 2d array, clearing all the text in the labels.
            for (int _i = 0; _i < maxEntries; _i++)
            {
                scheduleText[0, _i].Text = string.Empty;
                scheduleText[1, _i].Text = string.Empty;
            }
            //make sure there is data in the arrays
            if(projDates.Length > 0 && projNames.Length > 0)
            {
                //copy data into new array so that it can be sorted lazily
                DateTime[] projDatesCopy = new DateTime[projDates.Length];
                projDates.CopyTo(projDatesCopy, 0);
                //using min to avoid too many entries corrupting the data
                for (int i = 0; i < Math.Min(scheduleText.Length/2, projDates.Length); i++)
                {
                    //put the minimum in the label
                    scheduleText[1, i].Text = projDatesCopy.Min().ToString();
                    //remove 12:00:00 from the end of the string
                    scheduleText[1, i].Text = scheduleText[1, i].Text.Remove(scheduleText[1, i].Text.Length - 12);
                    //set the linking number of the schedule slot to the array index of the values in that slot
                    linkedButton.SetValue(Array.IndexOf(projDatesCopy, projDatesCopy.Min()), i);
                    //use the linking number to set the project name
                    scheduleText[0, i].Text = projNames.GetValue(linkedButton[i]).ToString();

                    //fill the projDatesCopy value with the maximum possible value so that my lazy sorting works
                    projDatesCopy[linkedButton[i]] = DateTime.MaxValue;
                    //projDatesCopy.SetValue(DateTime.MaxValue, Array.IndexOf(projDatesCopy, projDatesCopy.Min()));
                }
            }
        }
        private void SaveSchedule()
        {
            try
            {
                //delete the old save
                if (File.Exists(nameSavePath))
                {
                    File.Delete(nameSavePath);
                }
                if (File.Exists(dateSavePath))
                {
                    File.Delete(dateSavePath);
                }
            }
            catch
            {
                //grrrrr
                MessageBox.Show("Stupid Windows says you dont have access to your own files. Try restarting the app.");
                return;
            }
           
            //whether or not delete was necessary, create new file
            //File.Create(savePath);
            try
            {
                using (StreamWriter sw = new StreamWriter(nameSavePath))
                {
                    for (int i = 0; i < (scheduleText.Length)/2; i++)
                    {
                        if (scheduleText[0, i].Text != "")
                        {
                            sw.WriteLine(scheduleText[0, i].Text);
                        }
                    }
                }
            }
            catch
            {
                //it seems to throw an exception every time even though it works
                //fixed it, didnt know I needed to divide the length by the number of dimensions in the array
                MessageBox.Show("Dint work");
            }
            try
            {
                using (StreamWriter sw = new StreamWriter(dateSavePath))
                {
                    for (int i = 0; i < (scheduleText.Length)/2; i++)
                    {
                        if (scheduleText[1, i].Text != "")
                        {
                            sw.WriteLine(scheduleText[1, i].Text);
                        }
                    }
                }
            }
            catch
            {
                //it seems to throw an exception every time even though it works
                MessageBox.Show("Dint work");
            }
        }
        private void LoadSchedule()
        {
            /*
            much better and more efficient code
            if (File.Exists(savePath))
            {
                using (StreamReader sr = new StreamReader(savePath))
                {
                    for(int i = 0; i < scheduleText.Length; i++) 
                    {
                        if (sr.Peek() >= 0)
                        {
                            Array.Resize(ref projNames, projNames.Length + 1);
                            projNames[projNames.Length - 1] = sr.ReadLine();
                            Array.Resize(ref projDates, projDates.Length + 1);
                            //readd the time so it can be read as a datetime
                            projDates[projDates.Length - 1] = DateTime.Parse(string.Concat(sr.ReadLine(), " 12:00:00"));
                        }
                        UpdateSchedule();
                    }
                }
            */
            //worse code that uses two files >:(((
            //also I had to recode a bunhc of other stuff too

            //default to the max possible number of entries in the table. 
            int numEntries = maxEntries;
            if (File.Exists(nameSavePath) && File.Exists(dateSavePath))
            {
                //clear the old data from the arrays
                projNames = new string[0];
                projDates = new DateTime[0];
                //set the local boolean to false
                bool invalidSave = false;

                using (StreamReader sr = new StreamReader(nameSavePath))
                {
                    //up to 8 times,
                    for (int i = 0; i < scheduleText.Length/2; i++)
                    {
                        //as long as there is a line left in the savedata,
                        if (sr.Peek() >= 0)
                        {
                            //expand the array by one place
                            Array.Resize(ref projNames, projNames.Length + 1);
                            //add the savedata to the array
                            projNames[projNames.Length - 1] = sr.ReadLine();
                        }
                        
                    }
                }

                //this one is more complicated because I had to work around some features of datetime 
                using (StreamReader sr = new StreamReader(dateSavePath))
                {
                    //stores the last read line so it can be finltered before being added
                    string parsedString = "";
                    //up to 8 times
                    for (int i = 0; i < scheduleText.Length/2; i++)
                    {
                        //as long as there is a line left in the savedata, 
                        if (sr.Peek() >= 0)
                        {
                            //expand the array by one place
                            Array.Resize(ref projDates, projDates.Length + 1);
                            try
                            {
                                //get the next line of savedata
                                parsedString = sr.ReadLine();
                                //if it wasnt nothing
                                if (parsedString != "")
                                {
                                    //store it as a date time, adding midnight to the end of it so it can be read properly.
                                    projDates[projDates.Length - 1] = DateTime.Parse(string.Concat(parsedString, " 12:00:00"));
                                } else
                                {
                                    //no input, set array entry to max value so it can be ignored
                                    projDates[projDates.Length - 1] = DateTime.MaxValue;
                                }
                            }
                            catch
                            {
                                //this generally only triggers if the DateTime.Parse failed and means that invalid text was saved in the file
                                invalidSave = true;
                            }
                        }
                    }
                }
                //show error message if save data was incorrect
                if (invalidSave)
                {
                    MessageBox.Show("Save Data was invalid.");
                    //empty the garbage data from the arrays
                    projNames = new string[0];
                    projDates = new DateTime[0];
                }
                else
                {
                    //everything's good, display the new schedule!
                    UpdateSchedule();
                }
            } else
            {
                MessageBox.Show("SaveData couldn't be found!");
            }
            
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveSchedule();
        }

        private void LoadButton_Click(object sender, EventArgs e)
        {
            LoadSchedule();
        }

        //checks if the save files were created, if not creates them.
        private void InitSaves()
        {
            //I dont think I need to do this but idr sue me
            if (!File.Exists(nameSavePath))
            {
                File.Create(nameSavePath);
            }
            if(!File.Exists(dateSavePath))
            {
                File.Create(dateSavePath);
            }
        }
    }
}
