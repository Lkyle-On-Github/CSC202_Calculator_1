﻿namespace GameOveer
{
    partial class GameOver
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            punishmentButton = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            label1.Location = new Point(41, 9);
            label1.Name = "label1";
            label1.Size = new Size(217, 46);
            label1.TabIndex = 0;
            label1.Text = "GAME OVER";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 55);
            label2.Name = "label2";
            label2.Size = new Size(310, 60);
            label2.TabIndex = 1;
            label2.Text = "You have lost like an Idiot! as a punishment, \r\nyou must click this button that will run a while\r\nloop until it successfully rolls a 1/1000 chance";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // punishmentButton
            // 
            punishmentButton.Location = new Point(96, 118);
            punishmentButton.Name = "punishmentButton";
            punishmentButton.Size = new Size(128, 30);
            punishmentButton.TabIndex = 3;
            punishmentButton.Text = "I deserve this";
            punishmentButton.UseVisualStyleBackColor = true;
            punishmentButton.Click += Punish_Click;
            // 
            // GameOver
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(322, 156);
            Controls.Add(punishmentButton);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "GameOver";
            Text = "Game Over";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button button1;
        private Button punishmentButton;
    }
}
