﻿namespace Higher_or_Lower
{
    partial class HigherorLower
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TopText = new Label();
            TargetLabel = new Label();
            Target = new Label();
            RangeLabel = new Label();
            onethruten = new Label();
            label1 = new Label();
            higher = new Button();
            lower = new Button();
            continuebuttonragh = new Button();
            streak = new Label();
            StreakLabel = new Label();
            yournumber = new Label();
            yourNumberLabel = new Label();
            SuspendLayout();
            // 
            // TopText
            // 
            TopText.AutoSize = true;
            TopText.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            TopText.Location = new Point(12, 9);
            TopText.Name = "TopText";
            TopText.Size = new Size(270, 20);
            TopText.TabIndex = 0;
            TopText.Text = "Will your number be higher or lower?";
            TopText.TextAlign = ContentAlignment.MiddleCenter;
            TopText.Click += label1_Click;
            // 
            // TargetLabel
            // 
            TargetLabel.AutoSize = true;
            TargetLabel.Font = new Font("Segoe UI", 9F);
            TargetLabel.Location = new Point(43, 29);
            TargetLabel.Name = "TargetLabel";
            TargetLabel.Size = new Size(86, 20);
            TargetLabel.TabIndex = 1;
            TargetLabel.Text = "Your Target:";
            TargetLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Target
            // 
            Target.AutoSize = true;
            Target.Font = new Font("Segoe UI", 9F);
            Target.Location = new Point(73, 49);
            Target.Name = "Target";
            Target.Size = new Size(17, 20);
            Target.TabIndex = 2;
            Target.Text = "T";
            Target.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // RangeLabel
            // 
            RangeLabel.AutoSize = true;
            RangeLabel.Font = new Font("Segoe UI", 9F);
            RangeLabel.Location = new Point(122, 69);
            RangeLabel.Name = "RangeLabel";
            RangeLabel.Size = new Size(54, 20);
            RangeLabel.TabIndex = 3;
            RangeLabel.Text = "Range:";
            RangeLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // onethruten
            // 
            onethruten.AutoSize = true;
            onethruten.Font = new Font("Segoe UI", 9F);
            onethruten.Location = new Point(126, 89);
            onethruten.Name = "onethruten";
            onethruten.Size = new Size(39, 20);
            onethruten.TabIndex = 4;
            onethruten.Text = "1-10";
            onethruten.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.Location = new Point(101, 176);
            label1.Name = "label1";
            label1.Size = new Size(101, 28);
            label1.TabIndex = 5;
            label1.Text = "Prediction";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // higher
            // 
            higher.Location = new Point(21, 208);
            higher.Name = "higher";
            higher.Size = new Size(94, 29);
            higher.TabIndex = 6;
            higher.Text = "Higher";
            higher.UseVisualStyleBackColor = true;
            higher.Click += Higher_Click;
            // 
            // lower
            // 
            lower.Location = new Point(177, 208);
            lower.Name = "lower";
            lower.Size = new Size(94, 29);
            lower.TabIndex = 7;
            lower.Text = "Lower";
            lower.UseVisualStyleBackColor = true;
            lower.Click += Lower_Click;
            // 
            // continuebuttonragh
            // 
            continuebuttonragh.Location = new Point(97, 254);
            continuebuttonragh.Name = "continuebuttonragh";
            continuebuttonragh.Size = new Size(94, 29);
            continuebuttonragh.TabIndex = 8;
            continuebuttonragh.Text = "Continue";
            continuebuttonragh.UseVisualStyleBackColor = true;
            continuebuttonragh.Click += Continue_Click;
            // 
            // streak
            // 
            streak.AutoSize = true;
            streak.Font = new Font("Segoe UI", 9F);
            streak.Location = new Point(136, 129);
            streak.Name = "streak";
            streak.Size = new Size(17, 20);
            streak.TabIndex = 10;
            streak.Text = "0";
            streak.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // StreakLabel
            // 
            StreakLabel.AutoSize = true;
            StreakLabel.Font = new Font("Segoe UI", 9F);
            StreakLabel.Location = new Point(122, 109);
            StreakLabel.Name = "StreakLabel";
            StreakLabel.Size = new Size(53, 20);
            StreakLabel.TabIndex = 9;
            StreakLabel.Text = "Streak:";
            StreakLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // yournumber
            // 
            yournumber.AutoSize = true;
            yournumber.Font = new Font("Segoe UI", 9F);
            yournumber.Location = new Point(218, 49);
            yournumber.Name = "yournumber";
            yournumber.Size = new Size(16, 20);
            yournumber.TabIndex = 12;
            yournumber.Text = "?";
            yournumber.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // yourNumberLabel
            // 
            yourNumberLabel.AutoSize = true;
            yourNumberLabel.Font = new Font("Segoe UI", 9F);
            yourNumberLabel.Location = new Point(177, 29);
            yourNumberLabel.Name = "yourNumberLabel";
            yourNumberLabel.Size = new Size(99, 20);
            yourNumberLabel.TabIndex = 11;
            yourNumberLabel.Text = "Your Number:";
            yourNumberLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // HigherorLower
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(301, 301);
            Controls.Add(yournumber);
            Controls.Add(yourNumberLabel);
            Controls.Add(streak);
            Controls.Add(StreakLabel);
            Controls.Add(continuebuttonragh);
            Controls.Add(lower);
            Controls.Add(higher);
            Controls.Add(label1);
            Controls.Add(onethruten);
            Controls.Add(RangeLabel);
            Controls.Add(Target);
            Controls.Add(TargetLabel);
            Controls.Add(TopText);
            Name = "HigherorLower";
            Text = "HIgher or Lower";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label TopText;
        private Label TargetLabel;
        private Label Target;
        private Label RangeLabel;
        private Label onethruten;
        private Label label1;
        private Button higher;
        private Button lower;
        private Button continuebuttonragh;
        private Label streak;
        private Label StreakLabel;
        private Label yournumber;
        private Label yourNumberLabel;
    }
}
