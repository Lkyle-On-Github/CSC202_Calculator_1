using GameOveer;
using System.Security.Cryptography;

namespace Higher_or_Lower
{
   
    public partial class HigherorLower : Form
    {
       //initialize the gameover page
        GameOver gameOver = new GameOver();

        //variables used for stuff
        bool choseHigher = false;
        bool round_over = false;
        int targetNum = 0;
        int yourNum = 0;
        int streakNum = 0;
        public HigherorLower()
        {
            //storign reference to self in gameOver so that it can boot back up the game
            gameOver.loser = this;

            InitializeComponent();
            //generate the first number
            Target.Text = (RandomNumberGenerator.GetInt32(9) + 1).ToString();
            //set buttons to their initial state
            lower.Enabled = true;
            higher.Enabled = true;
            continuebuttonragh.Enabled = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Lower_Click(object sender, EventArgs e)
        {
            int.TryParse(Target.Text, out targetNum);
            if (targetNum != 1)
            {
                DoChoice();
                choseHigher = false;
            }
            else
            {
                MessageBox.Show("if you choose that option you cant win!");
            }
            
        }

        private void Higher_Click(object sender, EventArgs e)
        {
            int.TryParse(Target.Text, out targetNum);
            if (targetNum != 10)
            {
                DoChoice();
                choseHigher = true;
            } else
            {
                MessageBox.Show("if you choose that option you cant win!");

            }
        }

        private void Continue_Click(object sender, EventArgs e)
        {
            round_over = false;

            //parse the random number
            int.TryParse(yournumber.Text, out yourNum);
            
            //if the player chose higher
            if (choseHigher)
            {
                //if the number was higher
                if(yourNum > targetNum)
                {
                    //start the next round
                    NewRound(true);
                }
                else
                {
                    //make sure the numbers werent equal
                    EqualsCheck();
                }
            }
            //if the player chose lwoer
            else
            {
                //if the number was lower
                if (yourNum < targetNum)
                {
                    //start the next round
                    NewRound(true);
                }
                else
                {
                    //make sure the numbers werent equal
                    EqualsCheck();
                }
            }


            //if no condition for restarting the round was met, that means the player lost
            if(!round_over)
            {
                //reset page to default values
                streakNum = 0;
                streak.Text = streakNum.ToString();
                lower.Enabled = true;
                higher.Enabled = true;
                continuebuttonragh.Enabled = false;
                yournumber.Text = "?";
                //send them to the game over page
                this.Hide();
                gameOver.Show();

            }
        }

        //chooses the numbers, and enables/disables the proper buttons
        private void DoChoice()
        {
            
            yournumber.Text = (RandomNumberGenerator.GetInt32(9) + 1).ToString();
            lower.Enabled = false;
            higher.Enabled = false;
            continuebuttonragh.Enabled = true;
        }

        private void EqualsCheck()
        {
            if(yourNum == targetNum)
            {
                MessageBox.Show("The Numbers Were Equal, Sorry about that!");
                NewRound(false);
            }
        }

        private void NewRound(bool _streak)
        {
            //set round_over, so the continue button doesnt take them to the lose screen
            round_over = true;
            //increase streak, if this was a win and not an equals exception
            if(_streak)
            {
                streakNum += 1;
                streak.Text = streakNum.ToString();
            }
            //reset buttons to starting state
            lower.Enabled = true;
            higher.Enabled = true;
            continuebuttonragh.Enabled = false;
            //generate new random number
            Target.Text = (RandomNumberGenerator.GetInt32(9) + 1).ToString();
            //reset yournum
            yournumber.Text = "?";
        }
    }
}
