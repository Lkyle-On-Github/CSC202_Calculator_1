using Higher_or_Lower;
using System.Security.Cryptography;

namespace GameOveer
{
    public partial class GameOver : Form
    {
        //variable that hogherorlower uses to store a reference to itself
        public HigherorLower loser;
        public GameOver()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void Punish_Click(object sender, EventArgs e)
        {
            while(RandomNumberGenerator.GetInt32(999) != 0)
            {
                ///does nothing
            }
            //boots back up the game and hides
            this.Hide();
            loser.Show();
        }
    }
}
