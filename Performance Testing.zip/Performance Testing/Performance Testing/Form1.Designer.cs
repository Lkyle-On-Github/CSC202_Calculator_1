﻿namespace Performance_Testing
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox = new TextBox();
            textBoxLabel = new Label();
            buttonLabel = new Label();
            submitButton = new Button();
            SuspendLayout();
            // 
            // textBox
            // 
            textBox.Location = new Point(265, 134);
            textBox.Name = "textBox";
            textBox.Size = new Size(125, 27);
            textBox.TabIndex = 0;
            // 
            // textBoxLabel
            // 
            textBoxLabel.AutoSize = true;
            textBoxLabel.Location = new Point(171, 72);
            textBoxLabel.Name = "textBoxLabel";
            textBoxLabel.Size = new Size(361, 20);
            textBoxLabel.TabIndex = 1;
            textBoxLabel.Text = "Hello please enter an integer for my testing purposes";
            // 
            // buttonLabel
            // 
            buttonLabel.AutoSize = true;
            buttonLabel.Location = new Point(144, 164);
            buttonLabel.Name = "buttonLabel";
            buttonLabel.Size = new Size(198, 20);
            buttonLabel.TabIndex = 2;
            buttonLabel.Text = "And then click submit please";
            // 
            // submitButton
            // 
            submitButton.Location = new Point(220, 192);
            submitButton.Name = "submitButton";
            submitButton.Size = new Size(94, 29);
            submitButton.TabIndex = 3;
            submitButton.Text = "Submit";
            submitButton.UseVisualStyleBackColor = true;
            submitButton.Click += submitButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(553, 233);
            Controls.Add(submitButton);
            Controls.Add(buttonLabel);
            Controls.Add(textBoxLabel);
            Controls.Add(textBox);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox;
        private Label textBoxLabel;
        private Label buttonLabel;
        private Button submitButton;
    }
}
