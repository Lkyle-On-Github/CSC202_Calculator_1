using System.Security.Cryptography;
using System.Diagnostics;

namespace Performance_Testing
{
    public partial class Form1 : Form
    {
        Stopwatch fillWatch = new Stopwatch();
        Stopwatch sortWatch = new Stopwatch();
        public Form1()
        {
            InitializeComponent();

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //get the input
            int entry = 0;
            if(int.TryParse(textBox.Text, out entry))
            {
                
                if (entry > 0 && entry < 100000)
                {
                    //do the array thing
                    int[] testArray = new int[entry];
                    fillWatch.Start();
                    for (int i = 0; i < testArray.Length; i++)
                    {
                        
                        testArray[i] = RandomNumberGenerator.GetInt32(50000);
                        
                       
                    }
                    fillWatch.Stop();
                    Debug.Print(fillWatch.ElapsedMilliseconds.ToString());

                    //sort
                    sortWatch.Start();
                    testArray.Sort();
                    sortWatch.Stop();
                    Debug.Print(sortWatch.ElapsedMilliseconds.ToString());
                    //let the user know they were successful, and close the application
                    MessageBox.Show("Thank you for your time.");
                    this.Close();
                } else
                {
                    MessageBox.Show("This data is useless to me.");
                    this.Close();
                }
            } else
            {

                MessageBox.Show("No no enter an integer please I need please please");
            }
        }
    }
}
