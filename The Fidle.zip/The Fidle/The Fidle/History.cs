﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using The_Fidle;
using static System.Windows.Forms.LinkLabel;

namespace History
{
    public partial class HistoryForm : Form
    {

        string historySavePath = string.Concat(Directory.GetCurrentDirectory(), "\\History");

        //arrays that will be initialized and explained later
        FileInfo[] historyFiles = new FileInfo[0];
        DateTime[] historyDateTime = new DateTime[0];
        DirectoryInfo historyFolder = new DirectoryInfo(string.Concat(Directory.GetCurrentDirectory(), "\\History"));

        public TheFidle gamePage;
        Label[,] guessHistory = new Label[6, 5];
        //the index of the current file, so that history can be iterated through in order
        int currIndex = 0;
        public HistoryForm()
        {
            //historyDateTime.sort
            //using min to avoid too many entries corrupting the data
            /*
            for (int i = 0; i < Math.Min(scheduleText.Length / 2, projDates.Length); i++)
            {
                //put the minimum in the label
                scheduleText[1, i].Text = projDatesCopy.Min().ToString();
            }
            */
            InitializeComponent();
            guessHistory = new Label[,] {
                {oneone, onetwo, onethree, onefour, onefive},
                {twoone, twotwo, twothree, twofour, twofive},
                {threeone, threetwo, threethree, threefour, threefive},
                {fourone, fourtwo, fourthree, fourfour, fourfive},
                {fiveone, fivetwo, fivethree, fivefour, fivefive},
                {sixone, sixtwo, sixthree, sixfour, sixfive}
            };
        }
        
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void LoadDay()
        {
            //empty the boxes of the last entry's colors
            foreach(Label label in guessHistory)
            {
                label.BackColor = SystemColors.Control;
            }

            string path = historySavePath + "/" + historyFiles[currIndex];
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    //read that day's answers
                    ansSpec.Text = sr.ReadLine();
                    ansWep.Text = sr.ReadLine();
                    ansGada.Text = sr.ReadLine();
                    ansGadb.Text = sr.ReadLine();
                    ansGadc.Text = sr.ReadLine();
                    guessesUsed.Text = sr.ReadLine();
                    char[] buffer = new char[3];
                    //current row on the display
                    int row = 0;
                    //using while instead of for here because it just ends whenever the stream runs out
                    while (sr.Peek() >= 0)
                    {


                        for (int i = 0; i < 5; i++)
                        {
                            sr.ReadBlock(buffer, 0, 3);
                            guessHistory[row, i].BackColor = GetColor(new string(buffer));
                        }
                        //skips the newline characters
                        sr.Read();
                        sr.Read();

                        row++;
                    }
                }
                
                historyDate.Text = historyDateTime[currIndex].ToShortDateString();
            } catch
            {
                MessageBox.Show("unable to fully read save data for this day");
            }
        //doing this out of try catch to avoid array out of bounds exception
            //cant go previous if you are looking at the first day
            if (currIndex == 0)
            {
                prevButton.Enabled = false;
            }
            else
            {
                prevButton.Enabled = true;
            }
            //cant go next if you are looking at the last day
            if (currIndex == historyFiles.Length - 1)
            {
                nextButton.Enabled = false;
            }
            else
            {
                nextButton.Enabled = true;
            }
        }

        private Color GetColor(string str)
        {
            switch(str)
            {
                case "GRN":
                    return Color.LimeGreen;
                case "YLW":
                    return Color.Khaki;
                case "GRY":
                    return Color.Gray;
                default:
                    return Color.Red;
            }
        }

        private void RefreshHistory()
        {
            //refresh directory
            historyFolder = new DirectoryInfo(historySavePath);
            //get array of all the files in the directory
            historyFiles = historyFolder.GetFiles();
            historyDateTime = new DateTime[historyFiles.Length];

            try
            {
                //create an array of datetimes to sort the files with
                
                for (int i = 0; i < historyFiles.Length; i++)
                {
                    //remove .txt
                    string name = historyFiles[i].Name.TrimEnd('.', 't', 'x', 't');
                    //replace dots with slashes
                    name = name.Replace(".", "/");
                    //fill new array
                    historyDateTime[i] = DateTime.Parse(name);
                }
                //I am finally brave enough to use array.sort
                Array.Sort(historyDateTime, historyFiles);
            }
            catch
            {
                MessageBox.Show("unable to parse save names");
            }
            //set index to the most recent day
            currIndex = historyFiles.Length - 1;
        }
        private void backButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            gamePage.Show();
        }

        private void HistoryForm_VisibleChanged(object sender, EventArgs e)
        {
            if(this.Visible)
            {
                RefreshHistory();
                LoadDay();
            }
        }

        private void prevButton_Click(object sender, EventArgs e)
        {
            currIndex -= 1;
            LoadDay();
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            currIndex += 1;
            LoadDay();
        }
    }
}
