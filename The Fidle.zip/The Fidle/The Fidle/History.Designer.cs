﻿namespace History
{
    partial class HistoryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.backButton = new System.Windows.Forms.Button();
            this.sixfive = new System.Windows.Forms.Label();
            this.sixfour = new System.Windows.Forms.Label();
            this.sixthree = new System.Windows.Forms.Label();
            this.sixtwo = new System.Windows.Forms.Label();
            this.sixone = new System.Windows.Forms.Label();
            this.fivefive = new System.Windows.Forms.Label();
            this.fivefour = new System.Windows.Forms.Label();
            this.fivethree = new System.Windows.Forms.Label();
            this.fivetwo = new System.Windows.Forms.Label();
            this.fiveone = new System.Windows.Forms.Label();
            this.fourfive = new System.Windows.Forms.Label();
            this.fourfour = new System.Windows.Forms.Label();
            this.fourthree = new System.Windows.Forms.Label();
            this.fourtwo = new System.Windows.Forms.Label();
            this.fourone = new System.Windows.Forms.Label();
            this.threefive = new System.Windows.Forms.Label();
            this.threefour = new System.Windows.Forms.Label();
            this.threethree = new System.Windows.Forms.Label();
            this.threetwo = new System.Windows.Forms.Label();
            this.threeone = new System.Windows.Forms.Label();
            this.twofive = new System.Windows.Forms.Label();
            this.twofour = new System.Windows.Forms.Label();
            this.twothree = new System.Windows.Forms.Label();
            this.twotwo = new System.Windows.Forms.Label();
            this.twoone = new System.Windows.Forms.Label();
            this.onefive = new System.Windows.Forms.Label();
            this.onefour = new System.Windows.Forms.Label();
            this.onethree = new System.Windows.Forms.Label();
            this.onetwo = new System.Windows.Forms.Label();
            this.oneone = new System.Windows.Forms.Label();
            this.historyDate = new System.Windows.Forms.Label();
            this.prevButton = new System.Windows.Forms.Button();
            this.gadgetsLabel = new System.Windows.Forms.Label();
            this.weaponLabel = new System.Windows.Forms.Label();
            this.specLabel = new System.Windows.Forms.Label();
            this.ansSpec = new System.Windows.Forms.Label();
            this.ansWep = new System.Windows.Forms.Label();
            this.ansGadb = new System.Windows.Forms.Label();
            this.ansGada = new System.Windows.Forms.Label();
            this.ansGadc = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.v = new System.Windows.Forms.Label();
            this.guessesUsed = new System.Windows.Forms.Label();
            this.nextButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(694, 20);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(94, 26);
            this.backButton.TabIndex = 42;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // sixfive
            // 
            this.sixfive.AutoSize = true;
            this.sixfive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixfive.Location = new System.Drawing.Point(208, 323);
            this.sixfive.MinimumSize = new System.Drawing.Size(50, 50);
            this.sixfive.Name = "sixfive";
            this.sixfive.Size = new System.Drawing.Size(50, 50);
            this.sixfive.TabIndex = 72;
            this.sixfive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixfour
            // 
            this.sixfour.AutoSize = true;
            this.sixfour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixfour.Location = new System.Drawing.Point(159, 323);
            this.sixfour.MinimumSize = new System.Drawing.Size(50, 50);
            this.sixfour.Name = "sixfour";
            this.sixfour.Size = new System.Drawing.Size(50, 50);
            this.sixfour.TabIndex = 71;
            this.sixfour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixthree
            // 
            this.sixthree.AutoSize = true;
            this.sixthree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixthree.Location = new System.Drawing.Point(110, 323);
            this.sixthree.MinimumSize = new System.Drawing.Size(50, 50);
            this.sixthree.Name = "sixthree";
            this.sixthree.Size = new System.Drawing.Size(50, 50);
            this.sixthree.TabIndex = 70;
            this.sixthree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixtwo
            // 
            this.sixtwo.AutoSize = true;
            this.sixtwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixtwo.Location = new System.Drawing.Point(61, 323);
            this.sixtwo.MinimumSize = new System.Drawing.Size(50, 50);
            this.sixtwo.Name = "sixtwo";
            this.sixtwo.Size = new System.Drawing.Size(50, 50);
            this.sixtwo.TabIndex = 69;
            this.sixtwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixone
            // 
            this.sixone.AutoSize = true;
            this.sixone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixone.Location = new System.Drawing.Point(12, 323);
            this.sixone.MinimumSize = new System.Drawing.Size(50, 50);
            this.sixone.Name = "sixone";
            this.sixone.Size = new System.Drawing.Size(50, 50);
            this.sixone.TabIndex = 68;
            this.sixone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivefive
            // 
            this.fivefive.AutoSize = true;
            this.fivefive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivefive.Location = new System.Drawing.Point(208, 274);
            this.fivefive.MinimumSize = new System.Drawing.Size(50, 50);
            this.fivefive.Name = "fivefive";
            this.fivefive.Size = new System.Drawing.Size(50, 50);
            this.fivefive.TabIndex = 67;
            this.fivefive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivefour
            // 
            this.fivefour.AutoSize = true;
            this.fivefour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivefour.Location = new System.Drawing.Point(159, 274);
            this.fivefour.MinimumSize = new System.Drawing.Size(50, 50);
            this.fivefour.Name = "fivefour";
            this.fivefour.Size = new System.Drawing.Size(50, 50);
            this.fivefour.TabIndex = 66;
            this.fivefour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivethree
            // 
            this.fivethree.AutoSize = true;
            this.fivethree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivethree.Location = new System.Drawing.Point(110, 274);
            this.fivethree.MinimumSize = new System.Drawing.Size(50, 50);
            this.fivethree.Name = "fivethree";
            this.fivethree.Size = new System.Drawing.Size(50, 50);
            this.fivethree.TabIndex = 65;
            this.fivethree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivetwo
            // 
            this.fivetwo.AutoSize = true;
            this.fivetwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivetwo.Location = new System.Drawing.Point(61, 274);
            this.fivetwo.MinimumSize = new System.Drawing.Size(50, 50);
            this.fivetwo.Name = "fivetwo";
            this.fivetwo.Size = new System.Drawing.Size(50, 50);
            this.fivetwo.TabIndex = 64;
            this.fivetwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fiveone
            // 
            this.fiveone.AutoSize = true;
            this.fiveone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fiveone.Location = new System.Drawing.Point(12, 274);
            this.fiveone.MinimumSize = new System.Drawing.Size(50, 50);
            this.fiveone.Name = "fiveone";
            this.fiveone.Size = new System.Drawing.Size(50, 50);
            this.fiveone.TabIndex = 63;
            this.fiveone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourfive
            // 
            this.fourfive.AutoSize = true;
            this.fourfive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourfive.Location = new System.Drawing.Point(208, 225);
            this.fourfive.MinimumSize = new System.Drawing.Size(50, 50);
            this.fourfive.Name = "fourfive";
            this.fourfive.Size = new System.Drawing.Size(50, 50);
            this.fourfive.TabIndex = 62;
            this.fourfive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourfour
            // 
            this.fourfour.AutoSize = true;
            this.fourfour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourfour.Location = new System.Drawing.Point(159, 225);
            this.fourfour.MinimumSize = new System.Drawing.Size(50, 50);
            this.fourfour.Name = "fourfour";
            this.fourfour.Size = new System.Drawing.Size(50, 50);
            this.fourfour.TabIndex = 61;
            this.fourfour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourthree
            // 
            this.fourthree.AutoSize = true;
            this.fourthree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourthree.Location = new System.Drawing.Point(110, 225);
            this.fourthree.MinimumSize = new System.Drawing.Size(50, 50);
            this.fourthree.Name = "fourthree";
            this.fourthree.Size = new System.Drawing.Size(50, 50);
            this.fourthree.TabIndex = 60;
            this.fourthree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourtwo
            // 
            this.fourtwo.AutoSize = true;
            this.fourtwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourtwo.Location = new System.Drawing.Point(61, 225);
            this.fourtwo.MinimumSize = new System.Drawing.Size(50, 50);
            this.fourtwo.Name = "fourtwo";
            this.fourtwo.Size = new System.Drawing.Size(50, 50);
            this.fourtwo.TabIndex = 59;
            this.fourtwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourone
            // 
            this.fourone.AutoSize = true;
            this.fourone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourone.Location = new System.Drawing.Point(12, 225);
            this.fourone.MinimumSize = new System.Drawing.Size(50, 50);
            this.fourone.Name = "fourone";
            this.fourone.Size = new System.Drawing.Size(50, 50);
            this.fourone.TabIndex = 58;
            this.fourone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threefive
            // 
            this.threefive.AutoSize = true;
            this.threefive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threefive.Location = new System.Drawing.Point(208, 176);
            this.threefive.MinimumSize = new System.Drawing.Size(50, 50);
            this.threefive.Name = "threefive";
            this.threefive.Size = new System.Drawing.Size(50, 50);
            this.threefive.TabIndex = 57;
            this.threefive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threefour
            // 
            this.threefour.AutoSize = true;
            this.threefour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threefour.Location = new System.Drawing.Point(159, 176);
            this.threefour.MinimumSize = new System.Drawing.Size(50, 50);
            this.threefour.Name = "threefour";
            this.threefour.Size = new System.Drawing.Size(50, 50);
            this.threefour.TabIndex = 56;
            this.threefour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threethree
            // 
            this.threethree.AutoSize = true;
            this.threethree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threethree.Location = new System.Drawing.Point(110, 176);
            this.threethree.MinimumSize = new System.Drawing.Size(50, 50);
            this.threethree.Name = "threethree";
            this.threethree.Size = new System.Drawing.Size(50, 50);
            this.threethree.TabIndex = 55;
            this.threethree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threetwo
            // 
            this.threetwo.AutoSize = true;
            this.threetwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threetwo.Location = new System.Drawing.Point(61, 176);
            this.threetwo.MinimumSize = new System.Drawing.Size(50, 50);
            this.threetwo.Name = "threetwo";
            this.threetwo.Size = new System.Drawing.Size(50, 50);
            this.threetwo.TabIndex = 54;
            this.threetwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threeone
            // 
            this.threeone.AutoSize = true;
            this.threeone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threeone.Location = new System.Drawing.Point(12, 176);
            this.threeone.MinimumSize = new System.Drawing.Size(50, 50);
            this.threeone.Name = "threeone";
            this.threeone.Size = new System.Drawing.Size(50, 50);
            this.threeone.TabIndex = 53;
            this.threeone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twofive
            // 
            this.twofive.AutoSize = true;
            this.twofive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twofive.Location = new System.Drawing.Point(208, 127);
            this.twofive.MinimumSize = new System.Drawing.Size(50, 50);
            this.twofive.Name = "twofive";
            this.twofive.Size = new System.Drawing.Size(50, 50);
            this.twofive.TabIndex = 52;
            this.twofive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twofour
            // 
            this.twofour.AutoSize = true;
            this.twofour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twofour.Location = new System.Drawing.Point(159, 127);
            this.twofour.MinimumSize = new System.Drawing.Size(50, 50);
            this.twofour.Name = "twofour";
            this.twofour.Size = new System.Drawing.Size(50, 50);
            this.twofour.TabIndex = 51;
            this.twofour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twothree
            // 
            this.twothree.AutoSize = true;
            this.twothree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twothree.Location = new System.Drawing.Point(110, 127);
            this.twothree.MinimumSize = new System.Drawing.Size(50, 50);
            this.twothree.Name = "twothree";
            this.twothree.Size = new System.Drawing.Size(50, 50);
            this.twothree.TabIndex = 50;
            this.twothree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twotwo
            // 
            this.twotwo.AutoSize = true;
            this.twotwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twotwo.Location = new System.Drawing.Point(61, 127);
            this.twotwo.MinimumSize = new System.Drawing.Size(50, 50);
            this.twotwo.Name = "twotwo";
            this.twotwo.Size = new System.Drawing.Size(50, 50);
            this.twotwo.TabIndex = 49;
            this.twotwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twoone
            // 
            this.twoone.AutoSize = true;
            this.twoone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twoone.Location = new System.Drawing.Point(12, 127);
            this.twoone.MinimumSize = new System.Drawing.Size(50, 50);
            this.twoone.Name = "twoone";
            this.twoone.Size = new System.Drawing.Size(50, 50);
            this.twoone.TabIndex = 48;
            this.twoone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // onefive
            // 
            this.onefive.AutoSize = true;
            this.onefive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onefive.Location = new System.Drawing.Point(208, 78);
            this.onefive.MinimumSize = new System.Drawing.Size(50, 50);
            this.onefive.Name = "onefive";
            this.onefive.Size = new System.Drawing.Size(50, 50);
            this.onefive.TabIndex = 47;
            this.onefive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // onefour
            // 
            this.onefour.AutoSize = true;
            this.onefour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onefour.Location = new System.Drawing.Point(159, 78);
            this.onefour.MinimumSize = new System.Drawing.Size(50, 50);
            this.onefour.Name = "onefour";
            this.onefour.Size = new System.Drawing.Size(50, 50);
            this.onefour.TabIndex = 46;
            this.onefour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // onethree
            // 
            this.onethree.AutoSize = true;
            this.onethree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onethree.Location = new System.Drawing.Point(110, 78);
            this.onethree.MinimumSize = new System.Drawing.Size(50, 50);
            this.onethree.Name = "onethree";
            this.onethree.Size = new System.Drawing.Size(50, 50);
            this.onethree.TabIndex = 45;
            this.onethree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // onetwo
            // 
            this.onetwo.AutoSize = true;
            this.onetwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onetwo.Location = new System.Drawing.Point(61, 78);
            this.onetwo.MinimumSize = new System.Drawing.Size(50, 50);
            this.onetwo.Name = "onetwo";
            this.onetwo.Size = new System.Drawing.Size(50, 50);
            this.onetwo.TabIndex = 44;
            this.onetwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // oneone
            // 
            this.oneone.AutoSize = true;
            this.oneone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.oneone.Location = new System.Drawing.Point(12, 78);
            this.oneone.MinimumSize = new System.Drawing.Size(50, 50);
            this.oneone.Name = "oneone";
            this.oneone.Size = new System.Drawing.Size(50, 50);
            this.oneone.TabIndex = 43;
            this.oneone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // historyDate
            // 
            this.historyDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.historyDate.Location = new System.Drawing.Point(12, 33);
            this.historyDate.Name = "historyDate";
            this.historyDate.Size = new System.Drawing.Size(246, 31);
            this.historyDate.TabIndex = 0;
            this.historyDate.Text = "label1";
            this.historyDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // prevButton
            // 
            this.prevButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prevButton.Location = new System.Drawing.Point(12, 23);
            this.prevButton.Name = "prevButton";
            this.prevButton.Size = new System.Drawing.Size(50, 50);
            this.prevButton.TabIndex = 73;
            this.prevButton.Text = "<";
            this.prevButton.UseVisualStyleBackColor = true;
            this.prevButton.Click += new System.EventHandler(this.prevButton_Click);
            // 
            // gadgetsLabel
            // 
            this.gadgetsLabel.AutoSize = true;
            this.gadgetsLabel.Location = new System.Drawing.Point(585, 96);
            this.gadgetsLabel.MinimumSize = new System.Drawing.Size(100, 0);
            this.gadgetsLabel.Name = "gadgetsLabel";
            this.gadgetsLabel.Size = new System.Drawing.Size(100, 16);
            this.gadgetsLabel.TabIndex = 76;
            this.gadgetsLabel.Text = "Gadgets";
            this.gadgetsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // weaponLabel
            // 
            this.weaponLabel.AutoSize = true;
            this.weaponLabel.Location = new System.Drawing.Point(371, 96);
            this.weaponLabel.MinimumSize = new System.Drawing.Size(100, 0);
            this.weaponLabel.Name = "weaponLabel";
            this.weaponLabel.Size = new System.Drawing.Size(100, 16);
            this.weaponLabel.TabIndex = 75;
            this.weaponLabel.Text = "Weapon";
            this.weaponLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // specLabel
            // 
            this.specLabel.AutoSize = true;
            this.specLabel.Location = new System.Drawing.Point(264, 96);
            this.specLabel.MinimumSize = new System.Drawing.Size(100, 0);
            this.specLabel.Name = "specLabel";
            this.specLabel.Size = new System.Drawing.Size(100, 16);
            this.specLabel.TabIndex = 74;
            this.specLabel.Text = "Specialization";
            this.specLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ansSpec
            // 
            this.ansSpec.AutoSize = true;
            this.ansSpec.Location = new System.Drawing.Point(264, 118);
            this.ansSpec.MinimumSize = new System.Drawing.Size(100, 0);
            this.ansSpec.Name = "ansSpec";
            this.ansSpec.Size = new System.Drawing.Size(100, 16);
            this.ansSpec.TabIndex = 82;
            this.ansSpec.Text = "Specialization";
            this.ansSpec.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ansWep
            // 
            this.ansWep.AutoSize = true;
            this.ansWep.Location = new System.Drawing.Point(371, 118);
            this.ansWep.MinimumSize = new System.Drawing.Size(100, 0);
            this.ansWep.Name = "ansWep";
            this.ansWep.Size = new System.Drawing.Size(100, 16);
            this.ansWep.TabIndex = 83;
            this.ansWep.Text = "Weapon";
            this.ansWep.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ansGadb
            // 
            this.ansGadb.AutoSize = true;
            this.ansGadb.Location = new System.Drawing.Point(585, 118);
            this.ansGadb.MinimumSize = new System.Drawing.Size(100, 0);
            this.ansGadb.Name = "ansGadb";
            this.ansGadb.Size = new System.Drawing.Size(100, 16);
            this.ansGadb.TabIndex = 84;
            this.ansGadb.Text = "Gadgets";
            this.ansGadb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ansGada
            // 
            this.ansGada.AutoSize = true;
            this.ansGada.Location = new System.Drawing.Point(475, 118);
            this.ansGada.MinimumSize = new System.Drawing.Size(100, 0);
            this.ansGada.Name = "ansGada";
            this.ansGada.Size = new System.Drawing.Size(100, 16);
            this.ansGada.TabIndex = 85;
            this.ansGada.Text = "Gadgets";
            this.ansGada.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ansGadc
            // 
            this.ansGadc.AutoSize = true;
            this.ansGadc.Location = new System.Drawing.Point(689, 118);
            this.ansGadc.MinimumSize = new System.Drawing.Size(100, 0);
            this.ansGadc.Name = "ansGadc";
            this.ansGadc.Size = new System.Drawing.Size(100, 16);
            this.ansGadc.TabIndex = 86;
            this.ansGadc.Text = "Gadgets";
            this.ansGadc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(398, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(246, 31);
            this.label1.TabIndex = 87;
            this.label1.Text = "Solution";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // v
            // 
            this.v.AutoSize = true;
            this.v.Location = new System.Drawing.Point(475, 154);
            this.v.MinimumSize = new System.Drawing.Size(100, 0);
            this.v.Name = "v";
            this.v.Size = new System.Drawing.Size(100, 16);
            this.v.TabIndex = 88;
            this.v.Text = "Guesses Used";
            this.v.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // guessesUsed
            // 
            this.guessesUsed.AutoSize = true;
            this.guessesUsed.Location = new System.Drawing.Point(475, 187);
            this.guessesUsed.MinimumSize = new System.Drawing.Size(100, 0);
            this.guessesUsed.Name = "guessesUsed";
            this.guessesUsed.Size = new System.Drawing.Size(100, 16);
            this.guessesUsed.TabIndex = 89;
            this.guessesUsed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nextButton
            // 
            this.nextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nextButton.Location = new System.Drawing.Point(208, 23);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(50, 50);
            this.nextButton.TabIndex = 90;
            this.nextButton.Text = ">";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // HistoryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.guessesUsed);
            this.Controls.Add(this.v);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ansGadc);
            this.Controls.Add(this.ansGada);
            this.Controls.Add(this.ansGadb);
            this.Controls.Add(this.ansWep);
            this.Controls.Add(this.ansSpec);
            this.Controls.Add(this.gadgetsLabel);
            this.Controls.Add(this.weaponLabel);
            this.Controls.Add(this.specLabel);
            this.Controls.Add(this.prevButton);
            this.Controls.Add(this.historyDate);
            this.Controls.Add(this.sixfive);
            this.Controls.Add(this.sixfour);
            this.Controls.Add(this.sixthree);
            this.Controls.Add(this.sixtwo);
            this.Controls.Add(this.sixone);
            this.Controls.Add(this.fivefive);
            this.Controls.Add(this.fivefour);
            this.Controls.Add(this.fivethree);
            this.Controls.Add(this.fivetwo);
            this.Controls.Add(this.fiveone);
            this.Controls.Add(this.fourfive);
            this.Controls.Add(this.fourfour);
            this.Controls.Add(this.fourthree);
            this.Controls.Add(this.fourtwo);
            this.Controls.Add(this.fourone);
            this.Controls.Add(this.threefive);
            this.Controls.Add(this.threefour);
            this.Controls.Add(this.threethree);
            this.Controls.Add(this.threetwo);
            this.Controls.Add(this.threeone);
            this.Controls.Add(this.twofive);
            this.Controls.Add(this.twofour);
            this.Controls.Add(this.twothree);
            this.Controls.Add(this.twotwo);
            this.Controls.Add(this.twoone);
            this.Controls.Add(this.onefive);
            this.Controls.Add(this.onefour);
            this.Controls.Add(this.onethree);
            this.Controls.Add(this.onetwo);
            this.Controls.Add(this.oneone);
            this.Controls.Add(this.backButton);
            this.Name = "HistoryForm";
            this.Text = "History";
            this.VisibleChanged += new System.EventHandler(this.HistoryForm_VisibleChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.Label sixfive;
        private System.Windows.Forms.Label sixfour;
        private System.Windows.Forms.Label sixthree;
        private System.Windows.Forms.Label sixtwo;
        private System.Windows.Forms.Label sixone;
        private System.Windows.Forms.Label fivefive;
        private System.Windows.Forms.Label fivefour;
        private System.Windows.Forms.Label fivethree;
        private System.Windows.Forms.Label fivetwo;
        private System.Windows.Forms.Label fiveone;
        private System.Windows.Forms.Label fourfive;
        private System.Windows.Forms.Label fourfour;
        private System.Windows.Forms.Label fourthree;
        private System.Windows.Forms.Label fourtwo;
        private System.Windows.Forms.Label fourone;
        private System.Windows.Forms.Label threefive;
        private System.Windows.Forms.Label threefour;
        private System.Windows.Forms.Label threethree;
        private System.Windows.Forms.Label threetwo;
        private System.Windows.Forms.Label threeone;
        private System.Windows.Forms.Label twofive;
        private System.Windows.Forms.Label twofour;
        private System.Windows.Forms.Label twothree;
        private System.Windows.Forms.Label twotwo;
        private System.Windows.Forms.Label twoone;
        private System.Windows.Forms.Label onefive;
        private System.Windows.Forms.Label onefour;
        private System.Windows.Forms.Label onethree;
        private System.Windows.Forms.Label onetwo;
        private System.Windows.Forms.Label oneone;
        private System.Windows.Forms.Label historyDate;
        private System.Windows.Forms.Button prevButton;
        private System.Windows.Forms.Label gadgetsLabel;
        private System.Windows.Forms.Label weaponLabel;
        private System.Windows.Forms.Label specLabel;
        private System.Windows.Forms.Label ansSpec;
        private System.Windows.Forms.Label ansWep;
        private System.Windows.Forms.Label ansGadb;
        private System.Windows.Forms.Label ansGada;
        private System.Windows.Forms.Label ansGadc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label v;
        private System.Windows.Forms.Label guessesUsed;
        private System.Windows.Forms.Button nextButton;
    }
}