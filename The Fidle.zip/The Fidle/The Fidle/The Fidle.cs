﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using History;

/*
WORDLE IMPLEMENTATION PLAN
spec/weapoins
(because they iwll mostly work the same way)
All the possible answers are stored in different arrays for each category, and one big array to make checking easier
at the start, store which array the answer is in in a variable

when an answer is submitted
first check if they are exactly the same
if so , green

otherwise, check if the guess is contained in the answer category variable
if so, yellow

otherwise, grey

the first index of each category is the name of the category
this way, the name can be accessed without interfering with validation or requiring some sort of lookup thing


functions:
find gun/find spec
returns the category of the gun/spec input
*/

/*
FILE IMPLEMENTAITON PLAN
in the bin create an answers folder
folders are full of files, named the day that they are the fidle solution for
since this is just a demonstration, there will only be 7 fidles, 1 for each day of the week

in the bin, create a history folder
every time you either win or lose on a fidle, create a file titled that day's date
for each row of the table, save the colors of that row as a line in the file
additionally, save whether or not they won and the number of guesses they used

when loading the files, load the most recent one, and go back in order
idk how to implement this part
 
 */

namespace The_Fidle
{
    
    public partial class TheFidle : Form
    {
        FileInfo[] ansFiles = new FileInfo[0];
        DateTime[] ansDateTime = new DateTime[0];
        DirectoryInfo ansFolder = new DirectoryInfo(string.Concat(Directory.GetCurrentDirectory(), "\\Answers"));

        HistoryForm historyPage = new HistoryForm();
        DateTime today = DateTime.Now;
        //location of the history for that form page
        string historySavePath = string.Concat(Directory.GetCurrentDirectory(), "\\History\\");
        string answersSavePath = string.Concat(Directory.GetCurrentDirectory(), "\\Answers");
        //visual display of previous guesses and their accuracy
        Label[,] guessHistory = new Label[6, 5];
        //what guess number you are on
        int guessNum = 0;
        //what your current guess is
        string[] currGuess = new string[5];

        #region Lists of valid answers
     //SPECIALIZATIONS
        string[] specs = new string[] {"Mesh Shield", "Charge 'N' Slam", "Winch Claw", "Goo Gun", "Dematerializer", "Guardian Turret", "Healing Beam", "Grappling Hook", "Cloaking Device", "Evasive Dash" };
        string[] Hspecs = new string[] { "\r\nH", "Mesh Shield", "Charge 'N' Slam", "Winch Claw", "Goo Gun" };
        string[] Mspecs = new string[] { "\r\nM", "Dematerializer", "Guardian Turret", "Healing Beam" };
        string[] Lspecs = new string[] { "\r\nL", "Grappling Hook", "Cloaking Device", "Evasive Dash" };

     //WEAPONS
        string[] weapons = new string[] 
        { 
            "93R", 
            "V9S", 
            "M11", 
            "R .357", 
            "BFR Titan", 
            ".50 Akimbo", 
            "XP-54", 
            "P90", 
            "M134 Minigun", 
            "Lewis Gun", 
            "M60", 
            "SH1900",
            "Cerberus 12GA",
            "Model 1887",
            "KS-23",
            "SA126",
            "LH1",
            "ARN-220",
            "AKM",
            "FCAR",
            "Famas",
            "SHAK-50",
            "SR-84",
            "CB-01 Repeater",
            "Pike-556",
            "Sword",
            "Dagger",
            "Dual Blades",
            "Riot Shield",
            "Spear",
            "Sledgehammer",
            "Recurve Bow",
            "Throwing Knives",
            "CL-40",
            "MGL32",
            "Flamethrower",

        };
        string[] pistols = new string[]
        {
            "\r\nPistol/Hand Cannon/\r\nRevolver/Handgun",
            "93R",
            "V9S",
            "M11",
            "R .357",
            "BFR Titan",
            ".50 Akimbo",
        };
        string[] machineGuns = new string[]
        {
            "\r\nMachine Gun/Minigun",
            "XP-54",
            "P90",
            "M134 Minigun",
            "Lewis Gun",
            "M60",
        };
        string[] shotguns = new string[]
        {
            "\r\nShotgun",
            "SH1900",
            "M26 Matter",
            "Cerberus 12GA",
            "Model 1887",
            "KS-23",
            "SA126",
        };
        string[] assaultRifles = new string[]
        {
            "\r\nAssault Rifle/\r\nBattle Rifle",
            "LH1",
            "ARN-220",
            "AKM",
            "FCAR",
            "Famas",
            "SHAK-50",
        };
        string[] precisionRifles = new string[]
        {
            "\r\nSniper Rifle/\r\nMarksman Rifle",
            "SR-84",
            "CB-01 Repeater",
            "Pike-556",
        };
        string[] melees = new string[]
        {
            "\r\nMelee",
            "Sword",
            "Dagger",
            "Dual Blades",
            "Riot Shield",
            "Spear",
            "Sledgehammer",
        };
        string[] specials = new string[]
        {
            "\r\nSpecial: not a gun or\r\nmelee/explosive/flame",
            "Recurve Bow",
            "Throwing Knives",
            "CL-40",
            "MGL32",
            "Flamethrower",
        };
        //GADGETS
        string[] gadgets = new string[]
        {
            "Healing Emitter",
            "Dome Shield",
            "RPG-7",
            "Lockbolt",
            "C4",
            "Barricade",
            "Anti-Gravity Cube",
            "Pyro Mine",
            "Jump Pad",
            "Zipline",
            "Defibrillator",
            "Glitch Trap",
            "APS Turret",
            "Data Reshaper",
            "Breach Drill",
            "Gas Mine",
            "Explosive Mine",
            "Proximity Sensor",
            "Sonar Grenade",
            "Thermal Bore",
            "Vanishing Bomb",
            "Breach Charge",
            "Glitch Grenade",
            "Nullifier",
            "Gravity Vortex",
            "Tracking Dart",
            "Gateway",
            "H+ Infuser",
            "Frag Grenade",
            "Goo Grenade",
            "Gas Grenade",
            "Pyro Grenade",
            "Smoke Grenade",
            "Flashbang",
        };
        #endregion
        
        string[] answers = new string[5];
        string ansSpecCat = "";
        string ansWepCat = "";
        public TheFidle()
        {
           historyPage.gamePage = this;
           InitializeComponent();
            //this took me way longer than I'd like to admit to figure out
            guessHistory = new Label[,] { 
                {oneone, onetwo, onethree, onefour, onefive},
                {twoone, twotwo, twothree, twofour, twofive},
                {threeone, threetwo, threethree, threefour, threefive},
                {fourone, fourtwo, fourthree, fourfour, fourfive},
                {fiveone, fivetwo, fivethree, fivefour, fivefive},
                {sixone, sixtwo, sixthree, sixfour, sixfive} 
            };
            loadAnswer();

            //MessageBox.Show(string.Concat(ansSpecCat, "", ansWepCat));
            
        }
        //my functions

        private void endGame()
        {
            specGuessBox.Enabled = false;
            weaponGuessBox.Enabled = false;
            aGuessBox.Enabled = false;
            bGuessBox.Enabled = false;
            cGuessBox.Enabled = false;
            submitButton.Enabled = false;
            //save data
            //prepare file name with dots
            string saveName = today.ToShortDateString().Replace("/", ".");
            //write data to this file
            if (!File.Exists(string.Concat(historySavePath, saveName, ".txt")))
            {
                using (StreamWriter sw = new StreamWriter(string.Concat(historySavePath, saveName, ".txt")))
                {
                    //first, write out all the answers
                    foreach(string answer in answers)
                    { 
                        sw.WriteLine(answer);
                    }
                    //then, the number of guesses used
                    sw.WriteLine(guessNum);
                    //finally, write the guess history
                    //cool that you can write and in for loops
                    //finishes when it gets to six or if the next row has an inset color
                    for (int i = 0; i < 6; i++)
                    {
                        if (guessHistory[i, 0].BackColor != SystemColors.Control)
                        {
                            for (int _i = 0; _i < 5; _i++)
                            {
                                switch (guessHistory[i, _i].BackColor.ToString())
                                {
                                    case "Color [LimeGreen]":
                                        sw.Write("GRN");
                                        break;
                                    case "Color [Khaki]":
                                        sw.Write("YLW");
                                        break;
                                    case "Color [Gray]":
                                        sw.Write("GRY");
                                        break;
                                }
                            } 
                                sw.Write("\r\n");
                        }
                        else
                        {
                            //if backcolor is white that means guesses are over, end writing.
                            return;
                        }
                    }
                }
            } else
            {
                MessageBox.Show("You have already done The Fidle today. Come back tommorow!");
            }
        }

        private void loadAnswer()
        {
            //refresh directory
            ansFolder = new DirectoryInfo(answersSavePath);
            //get array of all the files in the directory
            ansFiles = ansFolder.GetFiles();
            ansDateTime = new DateTime[ansFiles.Length];

            try
            {
                //create an array of datetimes to sort the files with

                for (int i = 0; i < ansFiles.Length; i++)
                {
                    //remove .txt
                    string name = ansFiles[i].Name.TrimEnd('.', 't', 'x', 't');
                    //replace dots with slashes
                    name = name.Replace(".", "/");
                    //fill new array
                    ansDateTime[i] = DateTime.Parse(name);
                }
                
            }
            catch
            {
                MessageBox.Show("unable to parse answer names");
            }
            //check each day in the answers folder
            for (int i = 0; i < ansDateTime.Length; i++)
            {
                //if they are the same day of the week as today
                if(today.DayOfWeek == ansDateTime[i].DayOfWeek)
                {
                    //Copy the answers from that day's files

                    using (StreamReader sr = new StreamReader(ansFiles[i].FullName))
                    {
                        for (int _i = 0; _i < 6 && sr.Peek() >= 0; _i++)
                        {
                            answers[_i] = sr.ReadLine();
                        }

                    }
                }
            }
            //get the weapon and specialization categories for today's answer
            ansSpecCat = findSpec(answers[0]);
            ansWepCat = findWeapon(answers[1]);
        }
        private void updateGuess()
        {
            //put the guesses into this array so they are faster to type and easier to iterate through
            currGuess[0] = specGuessBox.Text;
            currGuess[1] = weaponGuessBox.Text;
            currGuess[2] = aGuessBox.Text;
            currGuess[3] = bGuessBox.Text;
            currGuess[4] = cGuessBox.Text;
        }

        private string findSpec(string spec)
        {
            //if input is in any of these categories, return index 0 of that category, which holds the category name.
            if(Hspecs.Contains(spec))
            {
                return Hspecs[0];
            }
            if(Mspecs.Contains(spec))
            {
                return Mspecs[0];
            }
            if(Lspecs.Contains(spec))
            {
                return Lspecs[0]; 
            }
            //default return case, shouldnt be possible since validaiton was already checked
            MessageBox.Show("Got past validation but didnt match any valid specializations");
            return "none";
        }
        private string findWeapon(string wep)
        {
            
            //if input is in any of these categories, return index 0 of that category, which holds the category name.
            if(pistols.Contains(wep))
            {
                return pistols[0];
            }
            if(machineGuns.Contains(wep))
            {
                return machineGuns[0]; 
            }
            if(shotguns.Contains(wep))
            {
                return shotguns[0]; 
            }
            if(assaultRifles.Contains(wep))
            {
                return assaultRifles[0];
            }
            if(precisionRifles.Contains(wep))
            { 
                return precisionRifles[0]; 
            }
            if(melees.Contains(wep))
            {
                return melees[0];
            }
            if(specials.Contains(wep))
            {
                return specials[0]; 
            }
            //default return case, shouldnt be possible since validaiton was already checked
            MessageBox.Show("Got past validation but didnt match any valid weapons");
            return "none";
        }
        private Color[] interpretAnswer()
        {
            Color[] returnColors = new Color[5];
            
        //SPEC
            if (specs.Contains(currGuess[0]))
            {
                //determine how close it was
                if (currGuess[0] == answers[0])
                {
                    //if they match, green
                    returnColors[0] = Color.LimeGreen;
                } else
                {
                    if (findSpec(currGuess[0]) == ansSpecCat)
                    {
                        //if they same cat, yellow
                        returnColors[0] = Color.Khaki;
                    } else
                    {
                        //no matchy, grey
                        returnColors[0] = Color.Gray;
                    }
                }
                
            } else
            {
                //MessageBox.Show(currGuess[0]);
                //MessageBox.Show(currGuess[1]);
                returnColors[0] = Color.Red;
            }

         //WEAPON
            if (weapons.Contains(currGuess[1]))
            {
                //determine how close it was
                if (currGuess[1] == answers[1])
                {
                    //if they match, green
                    returnColors[1] = Color.LimeGreen;
                }
                else
                {
                    if (findWeapon(currGuess[1]) == ansWepCat)
                    {
                        //if they same cat, yellow
                        returnColors[1] = Color.Khaki;
                    }
                    else
                    {
                        //no matchy, grey
                        returnColors[1] = Color.Gray;
                    }
                }

            }
            else
            {
                returnColors[1] = Color.Red;
            }
        //GADGETS
            for (int i = 2; i < 5; i++)
            {
                if (gadgets.Contains(currGuess[i]))
                {
                    if (answers[i] == currGuess[i])
                    {
                        returnColors[i] = Color.LimeGreen;
                    }
                    else
                    {
                        if (answers.Contains(currGuess[i]))
                        {
                            returnColors[i] = Color.Khaki;
                        }
                        else
                        {
                            returnColors[i] = Color.Gray;
                        }
                    }
                }
                else
                {
                    returnColors[i] = Color.Red;
                }
                /*
                switch (currGuess[i])
                {
                    case "Green":
                        returnColors[i] = Color.LimeGreen;
                        break;
                    case "Grey":
                        returnColors[i] = Color.Gray;
                        break;
                    case "Yellow":
                        returnColors[i] = Color.Khaki;
                        break;
                    default:
                        returnColors[i] = Color.Red;
                        break;
                }
                */
            }
            //colors are ready!
            return returnColors;
        }

        //true if input is valid, false if not
        private bool validateInput(Color[] interpretation)
        {
            //the error message that is output at the end
            string errorMessage = "";

            //whether or not duplicate gadget erros will be checked for
            bool checkGadgetDupes = true;
            //cant use a for loop here since each individual input must be mapped to an individual and non-reducable output
            //hypothetically I could use a for loop if I do a lookup table but at that point im not really reducing complexity me thinks
            if (interpretation[0] == Color.Red)
            {
                errorMessage += "Not a valid specialization name! ";
            }
            if (interpretation[1] == Color.Red)
            {
                errorMessage += "Not a valid weapon name! ";
            }
            if (interpretation[2] == Color.Red)
            {
                errorMessage += "Gadget 1 has an invalid name! ";
                //do not display the error for duplicate gadgets if there is an invalid gadget
                checkGadgetDupes = false;
            }
            if (interpretation[3] == Color.Red)
            {
                errorMessage += "Gadget 2 has an invalid name! ";
                //do not display the error for duplicate gadgets if there is an invalid gadget
                checkGadgetDupes = false;
            }
            if (interpretation[4] == Color.Red)
            {
                errorMessage += "Gadget 3 has an invalid name! ";
                //do not display the error for duplicate gadgets if there is an invalid gadget
                checkGadgetDupes = false;
            }
            //if checking, compare gadgets to see if they are duplicates
            if (checkGadgetDupes)
            {
                //i is the index of the left side of the comparison, _i is the index of the right side.
                //since _i starts out 1 higher than i, two indeces will never be compared against eachother multiple times.
                //also starts at 2 because 0 and 1 arent gadgets.
                
                for (int i = 2; i < 4; i++)
                {
                    for (int _i = i + 1; _i < 5; _i++)
                    {
                        //if the two gadgets that were guessed are the same, add that to the error message
                        if (currGuess[i] == currGuess[_i])
                        {
                            errorMessage += string.Concat("Gadget ", (i - 1).ToString(), " is the same as Gadget ", (_i - 1).ToString(), "!");
                        }
                    }
                }
                
            }
            //if there is an error message, display it and return false, otherwise return true
            if(errorMessage != "")
            {
                MessageBox.Show(errorMessage);
                return false;
            }
            return true;
        }

        //auto generated functions
        private void submitButton_Click(object sender, EventArgs e)
        {
            //get the most recent guess
            updateGuess();
            //store the interpretation of the guess
            Color[] guessColors = interpretAnswer();
            //variable that will check if you won
            bool winCheck = true;
            //if the user's input passes validation
            if (validateInput(guessColors))
            {
                //update the boxes in this column
                for (int i = 0; i < guessColors.Length; i++)
                {
                    //set the color based on the interpreter's output
                    guessHistory[guessNum, i].BackColor = guessColors[i];
                    //set the text based on the input
                    if(i  == 0)
                    {
                        guessHistory[guessNum, i].Text = string.Concat(currGuess[i], findSpec(currGuess[i]));
                    }
                    if(i == 1)
                    {
                        guessHistory[guessNum, i].Text = string.Concat(currGuess[i], findWeapon(currGuess[i]));
                    }
                    if (i > 1)
                    {
                        guessHistory[guessNum, i].Text = currGuess[i];
                    }
                   

                    //if the color isnt green, you did not win
                    if (guessColors[i] != Color.LimeGreen)
                    {
                        winCheck = false;
                    }
                }
                

                //remove the input from boxes
                specGuessBox.Text = "";
                weaponGuessBox.Text = "";
                aGuessBox.Text = "";
                bGuessBox.Text = "";
                cGuessBox.Text = "";
                //increment the guess number
                guessNum++;
                //check for win
                if (winCheck)
                {
                    MessageBox.Show("You won!");
                    //run game end script
                    endGame();
                    return;
                }
                

                //otherwise, if out of guesses, assume loss
                if (guessNum >= 6)
                {
                    MessageBox.Show("You lost.");
                    //run game end script to save data
                    endGame();
                    return;
                }
                
            }

        }

        //added because the editor was bugged and double clicking an element is the only way I know to fix it and these are way too annoying to remove
        private void oneone_Click(object sender, EventArgs e)
        {
            
        }

        private void historyButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            historyPage.Show();
        }

        private void applyDate_Click(object sender, EventArgs e)
        {
            //swap today's date
            today = debugDatePicker.Value;
            //reset guesses
            foreach (Label label in guessHistory)
            {
                label.BackColor = SystemColors.Control;
            }
            guessNum = 0;
            //load new answer
            loadAnswer();
        }
    }
}
