﻿namespace The_Fidle
{
    partial class TheFidle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oneone = new System.Windows.Forms.Label();
            this.onetwo = new System.Windows.Forms.Label();
            this.onefour = new System.Windows.Forms.Label();
            this.onethree = new System.Windows.Forms.Label();
            this.onefive = new System.Windows.Forms.Label();
            this.twofive = new System.Windows.Forms.Label();
            this.twofour = new System.Windows.Forms.Label();
            this.twothree = new System.Windows.Forms.Label();
            this.twotwo = new System.Windows.Forms.Label();
            this.twoone = new System.Windows.Forms.Label();
            this.fourfive = new System.Windows.Forms.Label();
            this.fourfour = new System.Windows.Forms.Label();
            this.fourthree = new System.Windows.Forms.Label();
            this.fourtwo = new System.Windows.Forms.Label();
            this.fourone = new System.Windows.Forms.Label();
            this.threefive = new System.Windows.Forms.Label();
            this.threefour = new System.Windows.Forms.Label();
            this.threethree = new System.Windows.Forms.Label();
            this.threetwo = new System.Windows.Forms.Label();
            this.threeone = new System.Windows.Forms.Label();
            this.sixfive = new System.Windows.Forms.Label();
            this.sixfour = new System.Windows.Forms.Label();
            this.sixthree = new System.Windows.Forms.Label();
            this.sixtwo = new System.Windows.Forms.Label();
            this.sixone = new System.Windows.Forms.Label();
            this.fivefive = new System.Windows.Forms.Label();
            this.fivefour = new System.Windows.Forms.Label();
            this.fivethree = new System.Windows.Forms.Label();
            this.fivetwo = new System.Windows.Forms.Label();
            this.fiveone = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.specLabel = new System.Windows.Forms.Label();
            this.weaponLabel = new System.Windows.Forms.Label();
            this.gadgetsLabel = new System.Windows.Forms.Label();
            this.specGuessBox = new System.Windows.Forms.TextBox();
            this.weaponGuessBox = new System.Windows.Forms.TextBox();
            this.bGuessBox = new System.Windows.Forms.TextBox();
            this.cGuessBox = new System.Windows.Forms.TextBox();
            this.aGuessBox = new System.Windows.Forms.TextBox();
            this.debugDatePicker = new System.Windows.Forms.DateTimePicker();
            this.historyButton = new System.Windows.Forms.Button();
            this.applyDate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // oneone
            // 
            this.oneone.AutoSize = true;
            this.oneone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.oneone.Location = new System.Drawing.Point(12, 9);
            this.oneone.MinimumSize = new System.Drawing.Size(150, 50);
            this.oneone.Name = "oneone";
            this.oneone.Size = new System.Drawing.Size(150, 50);
            this.oneone.TabIndex = 0;
            this.oneone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.oneone.Click += new System.EventHandler(this.oneone_Click);
            // 
            // onetwo
            // 
            this.onetwo.AutoSize = true;
            this.onetwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onetwo.Location = new System.Drawing.Point(161, 9);
            this.onetwo.MinimumSize = new System.Drawing.Size(150, 50);
            this.onetwo.Name = "onetwo";
            this.onetwo.Size = new System.Drawing.Size(150, 50);
            this.onetwo.TabIndex = 1;
            this.onetwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // onefour
            // 
            this.onefour.AutoSize = true;
            this.onefour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onefour.Location = new System.Drawing.Point(459, 9);
            this.onefour.MinimumSize = new System.Drawing.Size(150, 50);
            this.onefour.Name = "onefour";
            this.onefour.Size = new System.Drawing.Size(150, 50);
            this.onefour.TabIndex = 3;
            this.onefour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // onethree
            // 
            this.onethree.AutoSize = true;
            this.onethree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onethree.Location = new System.Drawing.Point(310, 9);
            this.onethree.MinimumSize = new System.Drawing.Size(150, 50);
            this.onethree.Name = "onethree";
            this.onethree.Size = new System.Drawing.Size(150, 50);
            this.onethree.TabIndex = 2;
            this.onethree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // onefive
            // 
            this.onefive.AutoSize = true;
            this.onefive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.onefive.Location = new System.Drawing.Point(608, 9);
            this.onefive.MinimumSize = new System.Drawing.Size(150, 50);
            this.onefive.Name = "onefive";
            this.onefive.Size = new System.Drawing.Size(150, 50);
            this.onefive.TabIndex = 4;
            this.onefive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twofive
            // 
            this.twofive.AutoSize = true;
            this.twofive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twofive.Location = new System.Drawing.Point(608, 58);
            this.twofive.MinimumSize = new System.Drawing.Size(150, 50);
            this.twofive.Name = "twofive";
            this.twofive.Size = new System.Drawing.Size(150, 50);
            this.twofive.TabIndex = 9;
            this.twofive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twofour
            // 
            this.twofour.AutoSize = true;
            this.twofour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twofour.Location = new System.Drawing.Point(459, 58);
            this.twofour.MinimumSize = new System.Drawing.Size(150, 50);
            this.twofour.Name = "twofour";
            this.twofour.Size = new System.Drawing.Size(150, 50);
            this.twofour.TabIndex = 8;
            this.twofour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twothree
            // 
            this.twothree.AutoSize = true;
            this.twothree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twothree.Location = new System.Drawing.Point(310, 58);
            this.twothree.MinimumSize = new System.Drawing.Size(150, 50);
            this.twothree.Name = "twothree";
            this.twothree.Size = new System.Drawing.Size(150, 50);
            this.twothree.TabIndex = 7;
            this.twothree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twotwo
            // 
            this.twotwo.AutoSize = true;
            this.twotwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twotwo.Location = new System.Drawing.Point(161, 58);
            this.twotwo.MinimumSize = new System.Drawing.Size(150, 50);
            this.twotwo.Name = "twotwo";
            this.twotwo.Size = new System.Drawing.Size(150, 50);
            this.twotwo.TabIndex = 6;
            this.twotwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // twoone
            // 
            this.twoone.AutoSize = true;
            this.twoone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.twoone.Location = new System.Drawing.Point(12, 58);
            this.twoone.MinimumSize = new System.Drawing.Size(150, 50);
            this.twoone.Name = "twoone";
            this.twoone.Size = new System.Drawing.Size(150, 50);
            this.twoone.TabIndex = 5;
            this.twoone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourfive
            // 
            this.fourfive.AutoSize = true;
            this.fourfive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourfive.Location = new System.Drawing.Point(608, 156);
            this.fourfive.MinimumSize = new System.Drawing.Size(150, 50);
            this.fourfive.Name = "fourfive";
            this.fourfive.Size = new System.Drawing.Size(150, 50);
            this.fourfive.TabIndex = 19;
            this.fourfive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourfour
            // 
            this.fourfour.AutoSize = true;
            this.fourfour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourfour.Location = new System.Drawing.Point(459, 156);
            this.fourfour.MinimumSize = new System.Drawing.Size(150, 50);
            this.fourfour.Name = "fourfour";
            this.fourfour.Size = new System.Drawing.Size(150, 50);
            this.fourfour.TabIndex = 18;
            this.fourfour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourthree
            // 
            this.fourthree.AutoSize = true;
            this.fourthree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourthree.Location = new System.Drawing.Point(310, 156);
            this.fourthree.MinimumSize = new System.Drawing.Size(150, 50);
            this.fourthree.Name = "fourthree";
            this.fourthree.Size = new System.Drawing.Size(150, 50);
            this.fourthree.TabIndex = 17;
            this.fourthree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourtwo
            // 
            this.fourtwo.AutoSize = true;
            this.fourtwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourtwo.Location = new System.Drawing.Point(161, 156);
            this.fourtwo.MinimumSize = new System.Drawing.Size(150, 50);
            this.fourtwo.Name = "fourtwo";
            this.fourtwo.Size = new System.Drawing.Size(150, 50);
            this.fourtwo.TabIndex = 16;
            this.fourtwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fourone
            // 
            this.fourone.AutoSize = true;
            this.fourone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fourone.Location = new System.Drawing.Point(12, 156);
            this.fourone.MinimumSize = new System.Drawing.Size(150, 50);
            this.fourone.Name = "fourone";
            this.fourone.Size = new System.Drawing.Size(150, 50);
            this.fourone.TabIndex = 15;
            this.fourone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threefive
            // 
            this.threefive.AutoSize = true;
            this.threefive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threefive.Location = new System.Drawing.Point(608, 107);
            this.threefive.MinimumSize = new System.Drawing.Size(150, 50);
            this.threefive.Name = "threefive";
            this.threefive.Size = new System.Drawing.Size(150, 50);
            this.threefive.TabIndex = 14;
            this.threefive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threefour
            // 
            this.threefour.AutoSize = true;
            this.threefour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threefour.Location = new System.Drawing.Point(459, 107);
            this.threefour.MinimumSize = new System.Drawing.Size(150, 50);
            this.threefour.Name = "threefour";
            this.threefour.Size = new System.Drawing.Size(150, 50);
            this.threefour.TabIndex = 13;
            this.threefour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threethree
            // 
            this.threethree.AutoSize = true;
            this.threethree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threethree.Location = new System.Drawing.Point(310, 107);
            this.threethree.MinimumSize = new System.Drawing.Size(150, 50);
            this.threethree.Name = "threethree";
            this.threethree.Size = new System.Drawing.Size(150, 50);
            this.threethree.TabIndex = 12;
            this.threethree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threetwo
            // 
            this.threetwo.AutoSize = true;
            this.threetwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threetwo.Location = new System.Drawing.Point(161, 107);
            this.threetwo.MinimumSize = new System.Drawing.Size(150, 50);
            this.threetwo.Name = "threetwo";
            this.threetwo.Size = new System.Drawing.Size(150, 50);
            this.threetwo.TabIndex = 11;
            this.threetwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // threeone
            // 
            this.threeone.AutoSize = true;
            this.threeone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.threeone.Location = new System.Drawing.Point(12, 107);
            this.threeone.MinimumSize = new System.Drawing.Size(150, 50);
            this.threeone.Name = "threeone";
            this.threeone.Size = new System.Drawing.Size(150, 50);
            this.threeone.TabIndex = 10;
            this.threeone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixfive
            // 
            this.sixfive.AutoSize = true;
            this.sixfive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixfive.Location = new System.Drawing.Point(608, 254);
            this.sixfive.MinimumSize = new System.Drawing.Size(150, 50);
            this.sixfive.Name = "sixfive";
            this.sixfive.Size = new System.Drawing.Size(150, 50);
            this.sixfive.TabIndex = 29;
            this.sixfive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixfour
            // 
            this.sixfour.AutoSize = true;
            this.sixfour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixfour.Location = new System.Drawing.Point(459, 254);
            this.sixfour.MinimumSize = new System.Drawing.Size(150, 50);
            this.sixfour.Name = "sixfour";
            this.sixfour.Size = new System.Drawing.Size(150, 50);
            this.sixfour.TabIndex = 28;
            this.sixfour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixthree
            // 
            this.sixthree.AutoSize = true;
            this.sixthree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixthree.Location = new System.Drawing.Point(310, 254);
            this.sixthree.MinimumSize = new System.Drawing.Size(150, 50);
            this.sixthree.Name = "sixthree";
            this.sixthree.Size = new System.Drawing.Size(150, 50);
            this.sixthree.TabIndex = 27;
            this.sixthree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixtwo
            // 
            this.sixtwo.AutoSize = true;
            this.sixtwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixtwo.Location = new System.Drawing.Point(161, 254);
            this.sixtwo.MinimumSize = new System.Drawing.Size(150, 50);
            this.sixtwo.Name = "sixtwo";
            this.sixtwo.Size = new System.Drawing.Size(150, 50);
            this.sixtwo.TabIndex = 26;
            this.sixtwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // sixone
            // 
            this.sixone.AutoSize = true;
            this.sixone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sixone.Location = new System.Drawing.Point(12, 254);
            this.sixone.MinimumSize = new System.Drawing.Size(150, 50);
            this.sixone.Name = "sixone";
            this.sixone.Size = new System.Drawing.Size(150, 50);
            this.sixone.TabIndex = 25;
            this.sixone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivefive
            // 
            this.fivefive.AutoSize = true;
            this.fivefive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivefive.Location = new System.Drawing.Point(608, 205);
            this.fivefive.MinimumSize = new System.Drawing.Size(150, 50);
            this.fivefive.Name = "fivefive";
            this.fivefive.Size = new System.Drawing.Size(150, 50);
            this.fivefive.TabIndex = 24;
            this.fivefive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivefour
            // 
            this.fivefour.AutoSize = true;
            this.fivefour.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivefour.Location = new System.Drawing.Point(459, 205);
            this.fivefour.MinimumSize = new System.Drawing.Size(150, 50);
            this.fivefour.Name = "fivefour";
            this.fivefour.Size = new System.Drawing.Size(150, 50);
            this.fivefour.TabIndex = 23;
            this.fivefour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivethree
            // 
            this.fivethree.AutoSize = true;
            this.fivethree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivethree.Location = new System.Drawing.Point(310, 205);
            this.fivethree.MinimumSize = new System.Drawing.Size(150, 50);
            this.fivethree.Name = "fivethree";
            this.fivethree.Size = new System.Drawing.Size(150, 50);
            this.fivethree.TabIndex = 22;
            this.fivethree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fivetwo
            // 
            this.fivetwo.AutoSize = true;
            this.fivetwo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fivetwo.Location = new System.Drawing.Point(161, 205);
            this.fivetwo.MinimumSize = new System.Drawing.Size(150, 50);
            this.fivetwo.Name = "fivetwo";
            this.fivetwo.Size = new System.Drawing.Size(150, 50);
            this.fivetwo.TabIndex = 21;
            this.fivetwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fiveone
            // 
            this.fiveone.AutoSize = true;
            this.fiveone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.fiveone.Location = new System.Drawing.Point(12, 205);
            this.fiveone.MinimumSize = new System.Drawing.Size(150, 50);
            this.fiveone.Name = "fiveone";
            this.fiveone.Size = new System.Drawing.Size(150, 50);
            this.fiveone.TabIndex = 20;
            this.fiveone.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(337, 404);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(100, 36);
            this.submitButton.TabIndex = 39;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // specLabel
            // 
            this.specLabel.AutoSize = true;
            this.specLabel.Location = new System.Drawing.Point(37, 335);
            this.specLabel.MinimumSize = new System.Drawing.Size(100, 0);
            this.specLabel.Name = "specLabel";
            this.specLabel.Size = new System.Drawing.Size(100, 16);
            this.specLabel.TabIndex = 31;
            this.specLabel.Text = "Specialization";
            this.specLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // weaponLabel
            // 
            this.weaponLabel.AutoSize = true;
            this.weaponLabel.Location = new System.Drawing.Point(187, 335);
            this.weaponLabel.MinimumSize = new System.Drawing.Size(100, 0);
            this.weaponLabel.Name = "weaponLabel";
            this.weaponLabel.Size = new System.Drawing.Size(100, 16);
            this.weaponLabel.TabIndex = 32;
            this.weaponLabel.Text = "Weapon";
            this.weaponLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gadgetsLabel
            // 
            this.gadgetsLabel.AutoSize = true;
            this.gadgetsLabel.Location = new System.Drawing.Point(487, 335);
            this.gadgetsLabel.MinimumSize = new System.Drawing.Size(100, 0);
            this.gadgetsLabel.Name = "gadgetsLabel";
            this.gadgetsLabel.Size = new System.Drawing.Size(100, 16);
            this.gadgetsLabel.TabIndex = 33;
            this.gadgetsLabel.Text = "Gadgets";
            this.gadgetsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // specGuessBox
            // 
            this.specGuessBox.Location = new System.Drawing.Point(37, 354);
            this.specGuessBox.Name = "specGuessBox";
            this.specGuessBox.Size = new System.Drawing.Size(100, 22);
            this.specGuessBox.TabIndex = 34;
            // 
            // weaponGuessBox
            // 
            this.weaponGuessBox.Location = new System.Drawing.Point(187, 354);
            this.weaponGuessBox.Name = "weaponGuessBox";
            this.weaponGuessBox.Size = new System.Drawing.Size(97, 22);
            this.weaponGuessBox.TabIndex = 35;
            // 
            // bGuessBox
            // 
            this.bGuessBox.Location = new System.Drawing.Point(487, 354);
            this.bGuessBox.Name = "bGuessBox";
            this.bGuessBox.Size = new System.Drawing.Size(97, 22);
            this.bGuessBox.TabIndex = 37;
            // 
            // cGuessBox
            // 
            this.cGuessBox.Location = new System.Drawing.Point(637, 354);
            this.cGuessBox.Name = "cGuessBox";
            this.cGuessBox.Size = new System.Drawing.Size(97, 22);
            this.cGuessBox.TabIndex = 38;
            // 
            // aGuessBox
            // 
            this.aGuessBox.Location = new System.Drawing.Point(337, 354);
            this.aGuessBox.Name = "aGuessBox";
            this.aGuessBox.Size = new System.Drawing.Size(97, 22);
            this.aGuessBox.TabIndex = 36;
            // 
            // debugDatePicker
            // 
            this.debugDatePicker.Location = new System.Drawing.Point(685, 418);
            this.debugDatePicker.Name = "debugDatePicker";
            this.debugDatePicker.Size = new System.Drawing.Size(200, 22);
            this.debugDatePicker.TabIndex = 40;
            this.debugDatePicker.Value = new System.DateTime(2026, 2, 27, 17, 24, 12, 0);
            // 
            // historyButton
            // 
            this.historyButton.Location = new System.Drawing.Point(791, 20);
            this.historyButton.Name = "historyButton";
            this.historyButton.Size = new System.Drawing.Size(94, 26);
            this.historyButton.TabIndex = 41;
            this.historyButton.Text = "History";
            this.historyButton.UseVisualStyleBackColor = true;
            this.historyButton.Click += new System.EventHandler(this.historyButton_Click);
            // 
            // applyDate
            // 
            this.applyDate.Location = new System.Drawing.Point(791, 390);
            this.applyDate.Name = "applyDate";
            this.applyDate.Size = new System.Drawing.Size(94, 22);
            this.applyDate.TabIndex = 42;
            this.applyDate.Text = "Apply";
            this.applyDate.UseVisualStyleBackColor = true;
            this.applyDate.Click += new System.EventHandler(this.applyDate_Click);
            // 
            // TheFidle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 450);
            this.Controls.Add(this.applyDate);
            this.Controls.Add(this.historyButton);
            this.Controls.Add(this.debugDatePicker);
            this.Controls.Add(this.aGuessBox);
            this.Controls.Add(this.cGuessBox);
            this.Controls.Add(this.bGuessBox);
            this.Controls.Add(this.weaponGuessBox);
            this.Controls.Add(this.specGuessBox);
            this.Controls.Add(this.gadgetsLabel);
            this.Controls.Add(this.weaponLabel);
            this.Controls.Add(this.specLabel);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.sixfive);
            this.Controls.Add(this.sixfour);
            this.Controls.Add(this.sixthree);
            this.Controls.Add(this.sixtwo);
            this.Controls.Add(this.sixone);
            this.Controls.Add(this.fivefive);
            this.Controls.Add(this.fivefour);
            this.Controls.Add(this.fivethree);
            this.Controls.Add(this.fivetwo);
            this.Controls.Add(this.fiveone);
            this.Controls.Add(this.fourfive);
            this.Controls.Add(this.fourfour);
            this.Controls.Add(this.fourthree);
            this.Controls.Add(this.fourtwo);
            this.Controls.Add(this.fourone);
            this.Controls.Add(this.threefive);
            this.Controls.Add(this.threefour);
            this.Controls.Add(this.threethree);
            this.Controls.Add(this.threetwo);
            this.Controls.Add(this.threeone);
            this.Controls.Add(this.twofive);
            this.Controls.Add(this.twofour);
            this.Controls.Add(this.twothree);
            this.Controls.Add(this.twotwo);
            this.Controls.Add(this.twoone);
            this.Controls.Add(this.onefive);
            this.Controls.Add(this.onefour);
            this.Controls.Add(this.onethree);
            this.Controls.Add(this.onetwo);
            this.Controls.Add(this.oneone);
            this.Name = "TheFidle";
            this.Text = "TheFidle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label oneone;
        private System.Windows.Forms.Label onetwo;
        private System.Windows.Forms.Label onefour;
        private System.Windows.Forms.Label onethree;
        private System.Windows.Forms.Label onefive;
        private System.Windows.Forms.Label twofive;
        private System.Windows.Forms.Label twofour;
        private System.Windows.Forms.Label twothree;
        private System.Windows.Forms.Label twotwo;
        private System.Windows.Forms.Label twoone;
        private System.Windows.Forms.Label fourfive;
        private System.Windows.Forms.Label fourfour;
        private System.Windows.Forms.Label fourthree;
        private System.Windows.Forms.Label fourtwo;
        private System.Windows.Forms.Label fourone;
        private System.Windows.Forms.Label threefive;
        private System.Windows.Forms.Label threefour;
        private System.Windows.Forms.Label threethree;
        private System.Windows.Forms.Label threetwo;
        private System.Windows.Forms.Label threeone;
        private System.Windows.Forms.Label sixfive;
        private System.Windows.Forms.Label sixfour;
        private System.Windows.Forms.Label sixthree;
        private System.Windows.Forms.Label sixtwo;
        private System.Windows.Forms.Label sixone;
        private System.Windows.Forms.Label fivefive;
        private System.Windows.Forms.Label fivefour;
        private System.Windows.Forms.Label fivethree;
        private System.Windows.Forms.Label fivetwo;
        private System.Windows.Forms.Label fiveone;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label specLabel;
        private System.Windows.Forms.Label weaponLabel;
        private System.Windows.Forms.Label gadgetsLabel;
        private System.Windows.Forms.TextBox specGuessBox;
        private System.Windows.Forms.TextBox weaponGuessBox;
        private System.Windows.Forms.TextBox bGuessBox;
        private System.Windows.Forms.TextBox cGuessBox;
        private System.Windows.Forms.TextBox aGuessBox;
        private System.Windows.Forms.DateTimePicker debugDatePicker;
        private System.Windows.Forms.Button historyButton;
        private System.Windows.Forms.Button applyDate;
    }
}

